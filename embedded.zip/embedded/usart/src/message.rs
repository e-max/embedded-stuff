//#[macro_use]
//extern crate serde_derive;

#[derive(Debug, Serialize, Deserialize)]
pub enum Message {
    Magnet {
        x: i16,
        y: i16,
        z: i16,
    },
    NormalizedMagnet {
        x: f32,
        y: f32,
        z: f32,
    },
    Magnitude(f32),
    Gyro {
        x: f32,
        y: f32,
        z: f32,
    },
    Accel {
        x: f32,
        y: f32,
        z: f32,
    },
    Quaternion(f32, f32, f32, f32),
    All {
        magnet: (f32, f32, f32),
        gyro: (f32, f32, f32),
        accel: (f32, f32, f32),
    },
    None,
}

//#![feature(duration_extras)]

extern crate cobs;
extern crate serialport;
extern crate ssmarshal;

#[macro_use]
extern crate serde_derive;
use std::env;
use std::ffi::OsStr;
use std::io::{self, BufRead, BufReader};
use std::io::{Read, Write};
use std::str;
use std::sync::mpsc::{channel, Receiver, Sender};
use std::thread;
use std::time;
use std::time::Duration;

use serialport::{
    BaudRate, DataBits, FlowControl, Parity, SerialPort, SerialPortSettings, StopBits,
};

mod message;

use message::Message;

const SETTINGS: SerialPortSettings = SerialPortSettings {
    baud_rate: BaudRate::Baud115200,
    data_bits: DataBits::Eight,
    parity: Parity::None,
    stop_bits: StopBits::One,
    flow_control: FlowControl::None,
    timeout: Duration::from_secs(3600),
};

fn main() {
    let path = env::args()
        .skip(1)
        .next()
        .expect("Expected path to serial device");
    //println!("opening port: {:?}", path);
    //
    //

    let (txread, rxread) = channel();
    let (txwrite, rxwrite) = channel();

    if path != "-" {
        let mut portw = serialport::open_with_settings(&path, &SETTINGS).unwrap();
        let mut portr = portw.try_clone().unwrap();

        let reader = thread::spawn(move || read_usart(txread, portr));
        let writer = thread::spawn(move || write_usart(rxwrite, portw));
        let processor = thread::spawn(move || process(rxread));

        reader.join().unwrap();
        writer.join().unwrap();
        processor.join().unwrap();
    } else {
        let reader = thread::spawn(move || read_stdin(txread));
        let processor = thread::spawn(move || process(rxread));
        reader.join().unwrap();
        processor.join().unwrap();
    }
}

struct Counter {
    counter: u64,
    bytes: u64,
    now: time::Instant,
}

impl Counter {
    pub fn new() -> Counter {
        Counter {
            counter: 0,
            bytes: 0,
            now: time::Instant::now(),
        }
    }

    pub fn count(&mut self, n: usize) {
        self.counter += 1;
        self.bytes += n as u64;
        if self.now.elapsed().as_secs() > 0 {
            //println!("bytes/s = {:?}", n * (frame.unwrap().len() + 1));
            eprintln!(
                "counter = {:?}",
                self.counter / self.now.elapsed().as_secs()
            );
            eprintln!("bytes/s = {:?}", self.bytes / self.now.elapsed().as_secs());
            self.counter = 0;
            self.bytes = 0;
            self.now = time::Instant::now();
        }
    }
}

fn read_stdin(tx: Sender<Message>) {
    let stdin = io::stdin();
    let mut n = 0;
    let mut now = time::Instant::now();
    let mut counter = Counter::new();
    for mut frame in BufReader::new(stdin.lock()).split(0) {
        match frame
            .map_err(|e| format!("{:?}", e))
            .map(|vec| {
                counter.count(vec.len() + 1);
                vec
            })
            .and_then(|mut vec| decode(&mut vec))
        {
            Ok(msg) => tx.send(msg).unwrap(),
            Err(e) => {
                println!("{:?}", e);
            }
        }
    }
}

fn read_usart(tx: Sender<Message>, mut port: Box<SerialPort>) {
    //let mut pool = Pool::with_capacity(5, 0, || Vec::with_capacity(512));
    let mut reader = BufReader::new(port);
    let mut n = 0;
    let mut vec: Vec<u8> = Vec::with_capacity(512);
    let mut counter = Counter::new();

    loop {
        vec.clear();
        n = reader.read_until(0u8, &mut vec).unwrap();
        counter.count(n);
        vec.truncate(n - 1);
        match decode(&mut vec) {
            Ok(msg) => tx.send(msg).unwrap(),
            Err(e) => {
                println!("{:?}", e);
            }
        }
    }
}

fn decode(mut vec: &mut [u8]) -> Result<Message, String> {
    let n =
        cobs::decode_in_place(&mut vec).map_err(|e| format!("Cannot deserializ: e = {:?}", e))?;
    if n > 0 {
        ssmarshal::deserialize::<Message>(&vec[0..n])
            .map(|(msg, _)| msg)
            .map_err(|e| format!("Cannot deserializ: e = {:?}", e))
    } else {
        Err("Cannot deserializ: 0 byte returned".to_owned())
    }
}

fn process(rx: Receiver<Message>) {
    for mut msg in rx {
        process_message(msg);
    }
}

fn process_message(m: Message) {
    match m {
        Message::Magnet { x, y, z } => println!("{} {} {}", x, y, z),
        Message::NormalizedMagnet { x, y, z } => println!("{} {} {}", x, y, z),
        Message::Quaternion(n, x, y, z) => process_quaternion(n, x, y, z),
        Message::All {
            magnet: (mx, my, mz),
            gyro: (gr_x, gr_y, gr_z),
            accel: (ac_x, ac_y, ac_z),
        } => println!(
            "{}, {}, {}, {}, {}, {}, {}, {}, {}",
            mx, my, mz, gr_x, gr_y, gr_z, ac_x, ac_y, ac_z
        ),
        Message::None => {}
        _ => println!("{:?}", m),
    }
}

fn write_usart(rx: Receiver<Vec<u8>>, mut port: Box<SerialPort>) {
    //let mut buf: [u8; 1] = [5; 1];
    let mut n = 0;
    for buf in rx {
        n = port.write(&buf).unwrap();
        println!("written n = {:?}", n);
    }
    println!("\x1B[31;1m \x1B[0m");
}

fn process_quaternion(n: f32, x: f32, y: f32, z: f32) {
    eprint!("{:.3} {:.3} {:.3} {:.3}\n", n, x, y, z);
}

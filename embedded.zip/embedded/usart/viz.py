# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt
import numpy as np

a = np.loadtxt("./data.txt")
(x, y, z) = np.transpose(a)


p1 = plt.subplot(111);
p1.plot(x, y, 'bo')
p1.plot(y, z, 'go')
p1.plot(z, x, 'ro')
__import__('ipdb').set_trace()
p1.show()




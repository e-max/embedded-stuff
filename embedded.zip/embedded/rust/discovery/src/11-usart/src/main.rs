#![deny(unsafe_code)]
#![no_std]

extern crate aux11;
extern crate cobs;
extern crate embedded_hal as hal;
#[macro_use]
extern crate serde_derive;
extern crate ssmarshal;
extern crate stm32f30x;
extern crate stm32f30x_hal;

use hal::blocking::delay::DelayMs;

use stm32f30x_hal::delay::Delay;
use stm32f30x_hal::time::MonoTimer;

use stm32f30x::usart1::RegisterBlock;
use stm32f30x_hal::serial::Serial;

#[derive(Debug, Serialize)]
enum Message {
    Msg(u8),
    None,
}

fn main() {
    // let (_usart1, _mono_timer, _itm, mut _delay) = aux11::init();
    let params = aux11::init();
    let usart1: &RegisterBlock = params.0;
    let mono_timer: MonoTimer = params.1;
    let mut delay: Delay = params.3;
    let s = "hello world\n";

    //loop {
    //for b in s.bytes() {
    //while usart1.isr.read().txe().bit_is_clear() {}
    //usart1.tdr.write(|w| w.tdr().bits(u16::from(b)));
    //}
    //delay.delay_ms(1000 as u32);
    //}
    while usart1.isr.read().txe().bit_is_clear() {}
    usart1.tdr.write(|w| w.tdr().bits(0));

    let mut buf: [u8; 32] = [0; 32];
    let mut buf1: [u8; 32] = [0; 32];
    let mut b: u8 = 0;

    let msg = Message::Msg(5);
    let n1 = ssmarshal::serialize(&mut buf1, &msg).unwrap();
    let n = cobs::encode(&mut buf1[0..n1], &mut buf);

    //let n = cobs::encode(s.as_bytes(), &mut buf);
    loop {
        //while usart1.isr.read().rxne().bit_is_clear() {}
        //b = usart1.rdr.read().rdr().bits() as u8;

        for b in &buf[0..n] {
            while usart1.isr.read().txe().bit_is_clear() {}
            usart1.tdr.write(|w| w.tdr().bits(u16::from(*b)));
        }
        while usart1.isr.read().txe().bit_is_clear() {}
        usart1.tdr.write(|w| w.tdr().bits(0));
    }
}

# Echo server

Let's merge transmission and reception into a single program and write an echo server. An echo
server sends back to the client the same text it sent. For this application, the microcontroller
will be the server and you and your laptop will be the client.

This should be straightforward to implement. (hint: do it byte by byte)

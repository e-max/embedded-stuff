#![deny(unsafe_code)]
#![no_std]

#[macro_use]
extern crate aux_madgwick;
extern crate f3;
extern crate m;
#[macro_use]
extern crate serde_derive;
extern crate madgwick_show;

use core::f32::consts::PI;
pub use f3::led::Direction;
pub use f3::led::Led;
pub use f3::lsm303dlhc::I16x3;
use f3::lsm303dlhc::{AccelOdr, MagOdr};
use f3::{L3gd20, Lsm303dlhc};

use aux_madgwick::prelude::*;
use m::Float;

use core::fmt::{self, Write};

pub use f3::hal::stm32f30x::usart1;

use madgwick_show::messenger::Messenger;

// Number of samples to use for gyroscope calibration
const NSAMPLES: i32 = 256;

const M_BIAS_X: f32 = -143.;
const M_SCALE_X: f32 = 650.;

const M_BIAS_Y: f32 = -41.;
const M_SCALE_Y: f32 = 636.;

const M_BIAS_Z: f32 = -243.5;
const M_SCALE_Z: f32 = 589.5;

#[derive(Debug, Serialize)]
enum Message {
    Msg(&'static str),
    Magnet { x: i16, y: i16, z: i16 },
    RealMag(f32),
    None,
}

fn main() {
    const XY_GAIN: f32 = 1100.; // LSB / G
    const Z_GAIN: f32 = 980.; // LSB / G

    let (_led, mut _lsm303dlhc, mut _l3gd20, mut delay, mut usart1) = aux_madgwick::init();

    let mut led: Led = _led;
    let mut lsm303dlhc: Lsm303dlhc = _lsm303dlhc;
    let mut l3gd20: L3gd20 = _l3gd20;

    let mut messenger = Messenger::new(usart1);

    loop {
        let I16x3 { x, y, z } = lsm303dlhc.mag().unwrap();

        messenger.send(&Message::Magnet { x, y, z }).unwrap();

        delay.delay_ms(100_u16);
    }
}

#![no_std]

pub mod messenger {
    extern crate cobs;
    extern crate embedded_hal as hal;
    extern crate serde;
    extern crate ssmarshal;
    extern crate stm32f30x;
    use self::serde::Serialize;
    use messenger::stm32f30x::usart1::RegisterBlock;

    pub struct Messenger {
        usart1: &'static RegisterBlock,
        marsh_buf: [u8; 32],
        enc_buf: [u8; 32],
    }

    impl Messenger {
        pub fn new(usart1: &'static RegisterBlock) -> Messenger {
            while usart1.isr.read().txe().bit_is_clear() {}
            usart1.tdr.write(|w| w.tdr().bits(0));
            Messenger {
                usart1: usart1,
                marsh_buf: [0; 32],
                enc_buf: [0; 32],
            }
        }

        pub fn send<T: Serialize>(&mut self, msg: &T) -> Result<(), &'static str> {
            let mut n =
                ssmarshal::serialize(&mut self.marsh_buf, msg).map_err(|e| "got some error")?;
            n = cobs::encode(&self.marsh_buf[0..n], &mut self.enc_buf);
            for b in &self.enc_buf[0..n] {
                while self.usart1.isr.read().txe().bit_is_clear() {}
                self.usart1.tdr.write(|w| w.tdr().bits(u16::from(*b)));
            }
            while self.usart1.isr.read().txe().bit_is_clear() {}
            self.usart1.tdr.write(|w| w.tdr().bits(0));
            Ok(())
        }
    }

}

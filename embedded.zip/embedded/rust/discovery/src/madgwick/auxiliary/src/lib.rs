//! Initialization code

#![feature(lang_items)]
#![feature(macro_reexport)]
#![no_std]

extern crate cortex_m;
extern crate f3;

pub use cortex_m::asm::bkpt;
use cortex_m::itm;
pub use f3::hal::delay::Delay;
use f3::hal::i2c::I2c;
pub use f3::hal::prelude;
use f3::hal::prelude::*;
pub use f3::hal::serial::Serial;
use f3::hal::spi::Spi;
use f3::hal::stm32f30x;
use f3::hal::stm32f30x::USART1;
pub use f3::hal::stm32f30x::i2c1;
pub use f3::hal::stm32f30x::usart1;
use f3::l3gd20::{self, Odr};
pub use f3::led::Led;
pub use f3::lsm303dlhc::I16x3;
use f3::lsm303dlhc::{AccelOdr, MagOdr};
use f3::{L3gd20, Lsm303dlhc};

pub fn init() -> (
    Led,
    Lsm303dlhc,
    L3gd20,
    Delay,
    &'static mut usart1::RegisterBlock,
) {
    let cp = cortex_m::Peripherals::take().unwrap();
    let dp = stm32f30x::Peripherals::take().unwrap();

    let mut flash = dp.FLASH.constrain();
    let mut rcc = dp.RCC.constrain();

    let clocks = rcc.cfgr.freeze(&mut flash.acr);

    let delay = Delay::new(cp.SYST, clocks);

    // LEDS
    let mut gpioe = dp.GPIOE.split(&mut rcc.ahb);
    let led = gpioe
        .pe9
        .into_push_pull_output(&mut gpioe.moder, &mut gpioe.otyper);

    //Magnetometer
    let mut gpiob = dp.GPIOB.split(&mut rcc.ahb);
    let scl = gpiob.pb6.into_af4(&mut gpiob.moder, &mut gpiob.afrl);
    let sda = gpiob.pb7.into_af4(&mut gpiob.moder, &mut gpiob.afrl);

    let i2c = I2c::i2c1(dp.I2C1, (scl, sda), 400.khz(), clocks, &mut rcc.apb1);

    let mut lsm303dlhc = Lsm303dlhc::new(i2c).unwrap();

    lsm303dlhc.accel_odr(AccelOdr::Hz400).unwrap();
    lsm303dlhc.mag_odr(MagOdr::Hz220).unwrap();

    // USART

    let mut gpioa = dp.GPIOA.split(&mut rcc.ahb);

    let tx = gpioa.pa9.into_af7(&mut gpioa.moder, &mut gpioa.afrh);
    let rx = gpioa.pa10.into_af7(&mut gpioa.moder, &mut gpioa.afrh);
    Serial::usart1(dp.USART1, (tx, rx), 115_200.bps(), clocks, &mut rcc.apb2);

    // Gyroscope
    //

    let mut nss = gpioe
        .pe3
        .into_push_pull_output(&mut gpioe.moder, &mut gpioe.otyper);
    nss.set_high();

    let sck = gpioa.pa5.into_af5(&mut gpioa.moder, &mut gpioa.afrl);
    let miso = gpioa.pa6.into_af5(&mut gpioa.moder, &mut gpioa.afrl);
    let mosi = gpioa.pa7.into_af5(&mut gpioa.moder, &mut gpioa.afrl);

    let spi = Spi::spi1(
        dp.SPI1,
        (sck, miso, mosi),
        l3gd20::MODE,
        1.mhz(),
        clocks,
        &mut rcc.apb2,
    );

    let mut l3gd20 = L3gd20::new(spi, nss).unwrap();

    l3gd20.set_odr(Odr::Hz380).unwrap();

    unsafe {
        (
            led.into(),
            lsm303dlhc,
            l3gd20,
            delay,
            &mut *(USART1::ptr() as *mut _),
        )
    }
}

#[lang = "panic_fmt"]
unsafe extern "C" fn panic_fmt(
    args: ::core::fmt::Arguments,
    file: &'static str,
    line: u32,
    col: u32,
) -> ! {
    cortex_m::asm::bkpt();

    loop {}
}

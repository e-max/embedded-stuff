#![no_std]

extern crate aux7;
use core::ptr;

fn main() {
    let (itm, gpioe) = aux7::init();

    //unsafe {
        //// A magic address!
        //const GPIOE_BSRR: u32 = 0x48001018;

        //// Turn on the "North" LED (red)
        //ptr::write_volatile((GPIOE_BSRR as *mut u32) , 1 << 9);

        //// Turn on the "East" LED (green)
        //ptr::write_volatile((GPIOE_BSRR as *mut u32) , 1 << 11);

        //// Turn off the "North" LED
        //ptr::write_volatile((GPIOE_BSRR as *mut u32) , 1 << (9 + 16));

        //// Turn off the "East" LED
        //ptr::write_volatile((GPIOE_BSRR as *mut u32) , 1 << (11 + 16));
    //}
        // Turn on the North LED
    gpioe.bsrr.write(|w| w.bs9().set_bit());

    // Turn on the East LED
    gpioe.bsrr.write(|w| w.bs11().set_bit());

    // Turn off the North LED
    gpioe.bsrr.write(|w| w.br9().set_bit());

    // Turn off the East LED
    gpioe.bsrr.write(|w| w.br11().set_bit());

}

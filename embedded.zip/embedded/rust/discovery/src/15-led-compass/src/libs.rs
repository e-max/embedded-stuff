pub mod messenger {
    extern crate embedded_hal as hal;
    extern crate serde;
    use serde::Serialize;
    use stm32f30x::usart1::RegisterBlock;

    struct Messenger {
        usart1: RegisterBlock,
        marsh_buf: [u8; 32],
        enc_buf: [u8; 32],
    }

    impl Messenger {
        pub fn new(usart1: RegisterBlock) -> Messenger {
            while usart1.isr.read().txe().bit_is_clear() {}
            usart1.tdr.write(|w| w.tdr().bits(0));
            Messenger {
                usart1: usart1,
                marsh_buf: [0; 32],
                enc_buf: [0; 32],
            }
        }

        pub fn send<T: Serialize>(&mut self, msg: &T) -> Result<(), String> {
            let n = ssmarshal::serialize(self.marsh_buf, msg).map_err(|e| format!("%s", e))?;
            n = cobs::encode(self.marsh_buf[0..n], self.enc_buf);
            for b in self.enc_buf[0..n] {
                while self.usart1.isr.read().txe().bit_is_clear() {}
                self.usart1.tdr.write(|w| w.tdr().bits(u16::from(*b)));
            }
            while usart1.isr.read().txe().bit_is_clear() {}
            usart1.tdr.write(|w| w.tdr().bits(0));
        }
    }

}

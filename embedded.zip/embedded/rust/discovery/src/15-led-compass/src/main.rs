#![deny(unsafe_code)]
#![no_std]

#[macro_use]
extern crate aux15;
extern crate f3;
extern crate m;

pub use f3::led::Direction;
pub use f3::lsm303dlhc::I16x3;
use core::f32::consts::PI;

use aux15::prelude::*;
use m::Float;

use core::fmt::{self, Write};

pub use f3::hal::stm32f30x::usart1;

macro_rules! uprint {
    ($serial:expr, $($arg:tt)*) => {
        $serial.write_fmt(format_args!($($arg)*)).ok()
    };
}

macro_rules! uprintln {
    ($serial:expr, $fmt:expr) => {
        uprint!($serial, concat!($fmt, "\n"))
    };
    ($serial:expr, $fmt:expr, $($arg:tt)*) => {
        uprint!($serial, concat!($fmt, "\n"), $($arg)*)
    };
}

fn main() {
    const XY_GAIN: f32 = 1100.; // LSB / G
    const Z_GAIN: f32 = 980.; // LSB / G

    let (_leds, mut lsm303dlhc, mut delay, mut itm, mut usart1) = aux15::init();
    let mut serial = SerialPort { usart1 };

    loop {
        let I16x3 { x, y, z } = lsm303dlhc.mag().unwrap();

        let x = f32::from(x) / XY_GAIN;
        let y = f32::from(y) / XY_GAIN;
        let z = f32::from(z) / Z_GAIN;

        let mag = (x * x + y * y + z * z).sqrt();

        let real_mag = mag * 1_000.;
        uprintln!(serial, "{} mG", real_mag);

        delay.delay_ms(500_u16);
    }

}


struct SerialPort {
    usart1: &'static mut usart1::RegisterBlock,
}

impl Write for SerialPort {
    fn write_str(&mut self, s: &str) -> fmt::Result {
        // TODO implement this
        // hint: this will look very similar to the previous program
        for b in s.bytes() {
            while self.usart1.isr.read().txe().bit_is_clear() {}
            self.usart1.tdr.write(|w| w.tdr().bits(u16::from(b)));
        }
        Ok(())
    }
}

fn compass() {
    let (mut leds, mut lsm303dlhc, mut delay, _itm, _) = aux15::init();


    let mut prev_direction = 0;
    loop {
        let I16x3 { x, y, .. } = lsm303dlhc.mag().unwrap();

        let theta = (y as f32).atan2(x as f32);

        //if theta <= PI/8 && theta > -PI/8 {
        let dir = if theta <= PI/8.0 && theta > 0.0 {
            //0
            Direction::South
        } else if theta <= 3.0 * PI/8.0 && theta > PI/8.0 {
            Direction::Southeast
        } else if theta <= 5.0 * PI/8.0 && theta > 3.0 * PI/8.0 {
            // 90
            Direction::East
        } else if theta <= 7.0 * PI/8.0 && theta > 5.0 * PI/8.0 {
            // 135
            Direction::Northeast
        } else if theta <= PI && theta > 7.0 * PI/8.0 {
            // 18.00
            Direction::North
        } else if theta <= -7.0 * PI/8.0 && theta > -PI {
            // 18.00
            Direction::North
        } else if theta <= -5.0 * PI/8.0 && theta > -7.0 * PI/8.0 {
            Direction::Northwest
        } else if theta <= -3.0 * PI/8.0 && theta > -5.0 * PI/8.0 {
            // 270
            Direction::West
        } else if theta <= -PI/8.0 && theta > -3.0 * PI/8.0 {
            // 315
            Direction::Southwest
        } else if theta <= 0.0 && theta > -PI/8.0 {
            //360
            Direction::South
        } else { Direction::South} as usize;

        //leds.iter_mut().for_each(|led| led.off());
        if prev_direction  != dir {
            leds[prev_direction].off();
            leds[dir].on();
            prev_direction = dir;
        }

        //delay.delay_ms(1_000_u16);
        delay.delay_ms(1_00_u16);
    }
}

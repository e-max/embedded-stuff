#![no_std]

extern crate aux9;

//use aux9::tim6;
extern crate stm32f30x;

use stm32f30x::{rcc, tim6};


#[inline(never)]
fn delay(tim6: &tim6::RegisterBlock, ms: u16) {
    tim6.arr.write(|w| w.arr().bits(ms));
    tim6.cr1.write(|w|  
        w.cen().enabled()
    );

    while tim6.sr.read().uif().bit_is_clear() {}
    tim6.sr.write(|w| w.uif().clear_bit());
}

fn main() {
    //let (mut leds, _rcc, tim6) = aux9::init();
    let res = aux9::init();
    let mut leds = res.0;
    let rcc: &rcc::RegisterBlock = res.1;
    let tim6: &tim6::RegisterBlock = res.2;

    rcc.apb1enr.write(|w| w.tim6en().enabled());
    tim6.cr1.write(|w| { 
        w.cen().disabled();
        w.opm().one_pulse()
    });

    tim6.psc.write(|w| w.psc().bits(7999));



    // TODO initialize TIM6

    let ms = 50;
    loop {
        for curr in 0..8 {
            let next = (curr + 1) % 8;

            leds[next].on();
            delay(tim6, ms);
            leds[curr].off();
            delay(tim6, ms);
        }
    }
}

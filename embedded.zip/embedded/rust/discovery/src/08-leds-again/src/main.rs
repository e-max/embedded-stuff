#![deny(unsafe_code)]
#![no_std]

extern crate aux8;
extern crate cortex_m;
extern crate f3;
extern crate stm32f30x;
extern crate stm32f30x_hal as hal;

use stm32f30x::gpioc;
use stm32f30x::rcc;

fn main() {
    let res = aux8::init();
    let gpioe: &gpioc::RegisterBlock = res.0;
    let rcc: &rcc::RegisterBlock = res.1;

    // TODO initialize GPIOE

    rcc.ahbenr.write(|w| w.iopeen().enabled());

    gpioe.moder.write(|w| {
        w.moder8().output();
        w.moder9().output();
        w.moder10().output();
        w.moder11().output();
        w.moder12().output();
        w.moder13().output();
        w.moder14().output();
        w.moder15().output()
    });
    // Turn on all the LEDs in the compass
    gpioe.odr.write(|w| {
        w.odr8().set_bit();
        w.odr9().set_bit();
        w.odr10().set_bit();
        w.odr11().set_bit();
        w.odr12().set_bit();
        w.odr13().set_bit();
        w.odr14().set_bit();
        w.odr15().set_bit()
    });

    aux8::bkpt();
}

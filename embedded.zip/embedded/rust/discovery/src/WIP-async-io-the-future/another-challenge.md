# Another challenge

Let's increase the difficulty level.

Get rid of the echo server but every time the user sends the string `"reverse"`
reverse "spin" direction of the the LED roulette.

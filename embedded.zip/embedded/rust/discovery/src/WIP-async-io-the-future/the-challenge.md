# The challenge

In isolation, the `Timer` and `Serial` examples I showed you are no different
that our old code that relied on busy waiting. It's when you use them together
where you can see the usefulness of using an async API.

Your task is to merge the two previous into one and make the echo server and the
LED roulette run concurrently.

Have fun!

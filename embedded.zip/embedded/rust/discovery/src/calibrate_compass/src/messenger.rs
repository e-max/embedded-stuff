#![no_std]
extern crate cobs;
extern crate cortex_m;
extern crate embedded_hal as hal;
extern crate serde;
extern crate ssmarshal;
extern crate stm32f30x;
use self::serde::Serialize;
use core;
use messenger::cortex_m::itm;
use messenger::cortex_m::peripheral::ITM;
use messenger::stm32f30x::usart1::RegisterBlock;

type Result = core::result::Result<(), &'static str>;

pub trait Write {
    fn write(&mut self, buf: &[u8]);
}

pub struct Messenger<W: Write> {
    w: W,
    marsh_buf: [u8; 32],
    enc_buf: [u8; 32],
}

impl<W> Messenger<W>
where
    W: Write,
{
    pub fn new(w: W) -> Messenger<W> {
        let mut m = Messenger {
            w: w,
            marsh_buf: [0; 32],
            enc_buf: [0; 32],
        };
        m.end();
        m
    }

    pub fn send<T: Serialize>(&mut self, msg: &T) -> Result {
        let mut n = ssmarshal::serialize(&mut self.marsh_buf, msg).map_err(|e| "got some error")?;
        n = cobs::encode(&self.marsh_buf[0..n], &mut self.enc_buf);
        self.w.write(&self.enc_buf[0..n]);
        self.end();
        Ok(())
    }

    pub fn send_bytes(&mut self, bytes: &[u8]) {
        self.w.write(bytes);
    }

    pub fn end(&mut self) {
        self.w.write(&[0]);
    }
}

impl<'a> Write for &'a mut RegisterBlock {
    fn write(&mut self, buf: &[u8]) {
        for b in buf {
            while self.isr.read().txe().bit_is_clear() {}
            self.tdr.write(|w| w.tdr().bits(u16::from(*b)));
        }
        while self.isr.read().txe().bit_is_clear() {}
    }
}

impl<'a> Write for &'a mut ITM {
    fn write(&mut self, buf: &[u8]) {
        itm::write_all(&mut self.stim[0], buf);
        //itm::write_all(&mut self.stim[0], "hello".as_bytes());
    }
}

impl Write for ITM {
    fn write(&mut self, buf: &[u8]) {
        itm::write_all(&mut self.stim[0], buf);
        //itm::write_all(&mut self.stim[0], "hello".as_bytes());
    }
}

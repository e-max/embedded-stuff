#![deny(unsafe_code)]
#![no_std]

#[macro_use]
extern crate aux_calib;
extern crate f3;
extern crate m;
#[macro_use]
extern crate serde_derive;
extern crate calibrate_compass;

use core::f32::consts::PI;
use f3::Lsm303dlhc;
pub use f3::led::Direction;
pub use f3::lsm303dlhc::I16x3;
use f3::lsm303dlhc::{AccelOdr, MagOdr};

use aux_calib::prelude::*;
use m::Float;

use core::fmt::{self, Write};

pub use f3::hal::stm32f30x::usart1;

use calibrate_compass::messenger::Messenger;

#[derive(Debug, Serialize)]
enum Message {
    Msg(&'static str),
    Magnet { x: i16, y: i16, z: i16 },
    NormalizedMagnet { x: f32, y: f32, z: f32 },
    Magnitude(f32),
    Gyro { x: f32, y: f32, z: f32 },
    Accel { x: f32, y: f32, z: f32 },
    Quaternion(f32, f32, f32, f32),
    None,
}

const M_BIAS_X: f32 = -65.;
const M_SCALE_X: f32 = 563.0;

const M_BIAS_Y: f32 = -61.;
const M_SCALE_Y: f32 = 583.0;

const M_BIAS_Z: f32 = 14.5;
const M_SCALE_Z: f32 = 543.5;

//550.5 537.0 509.5

fn main() {
    const XY_GAIN: f32 = 1100.; // LSB / G
    const Z_GAIN: f32 = 980.; // LSB / G

    let (_leds, mut _lsm303dlhc, mut delay, mut itm, mut usart1) = aux_calib::init();

    let mut lsm303dlhc: Lsm303dlhc = _lsm303dlhc;

    //let mut messenger = Messenger::new(usart1);
    let mut messenger = Messenger::new(itm);

    loop {
        messenger.send(&Message::Msg("hello")).unwrap();
    }

    loop {
        let I16x3 { x, y, z } = lsm303dlhc.mag().unwrap();
        //let m_x = (x as f32 - M_BIAS_X) / M_SCALE_X;
        //let m_y = (y as f32 - M_BIAS_Y) / M_SCALE_Y;
        //let m_z = (z as f32 - M_BIAS_Z) / M_SCALE_Z;

        //let x = f32::from(x) / XY_GAIN;
        //let y = f32::from(y) / XY_GAIN;
        //let z = f32::from(z) / Z_GAIN;

        //let mag = (x * x + y * y + z * z).sqrt();

        //let real_mag = mag * 1_000.;
        //

        let m_x = (x as f32 - M_BIAS_X);
        let m_y = (y as f32 - M_BIAS_Y);
        let m_z = (z as f32 - M_BIAS_Z);

        messenger
            .send(&Message::Magnet { x: x, y: y, z: z })
            .unwrap();
        //messenger
        //.send(&Message::NormalizedMagnet {
        //x: m_x,
        //y: m_y,
        //z: m_z,
        //})
        //.unwrap();

        delay.delay_ms(10_u16);
    }
}

fn compass() {
    let (mut leds, mut lsm303dlhc, mut delay, _itm, _) = aux_calib::init();

    let mut prev_direction = 0;
    loop {
        let I16x3 { x, y, .. } = lsm303dlhc.mag().unwrap();

        let theta = (y as f32).atan2(x as f32);

        //if theta <= PI/8 && theta > -PI/8 {
        let dir = if theta <= PI / 8.0 && theta > 0.0 {
            //0
            Direction::South
        } else if theta <= 3.0 * PI / 8.0 && theta > PI / 8.0 {
            Direction::Southeast
        } else if theta <= 5.0 * PI / 8.0 && theta > 3.0 * PI / 8.0 {
            // 90
            Direction::East
        } else if theta <= 7.0 * PI / 8.0 && theta > 5.0 * PI / 8.0 {
            // 135
            Direction::Northeast
        } else if theta <= PI && theta > 7.0 * PI / 8.0 {
            // 18.00
            Direction::North
        } else if theta <= -7.0 * PI / 8.0 && theta > -PI {
            // 18.00
            Direction::North
        } else if theta <= -5.0 * PI / 8.0 && theta > -7.0 * PI / 8.0 {
            Direction::Northwest
        } else if theta <= -3.0 * PI / 8.0 && theta > -5.0 * PI / 8.0 {
            // 270
            Direction::West
        } else if theta <= -PI / 8.0 && theta > -3.0 * PI / 8.0 {
            // 315
            Direction::Southwest
        } else if theta <= 0.0 && theta > -PI / 8.0 {
            //360
            Direction::South
        } else {
            Direction::South
        } as usize;

        //leds.iter_mut().for_each(|led| led.off());
        if prev_direction != dir {
            leds[prev_direction].off();
            leds[dir].on();
            prev_direction = dir;
        }

        //delay.delay_ms(1_000_u16);
        delay.delay_ms(1_00_u16);
    }
}

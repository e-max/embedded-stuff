# macOS

All the tools can be install using [Homebrew]:

[Homebrew]: http://brew.sh/

``` console
$ brew cask install gcc-arm-embedded
$ brew install minicom openocd
```

If the `brew cask` command doesn't work (`Error: Unknown command: cask`), then run `brew tap
Caskroom/tap` first and try again.

That's all! Go to the [next section].

[next section]: 03-setup/verify.html

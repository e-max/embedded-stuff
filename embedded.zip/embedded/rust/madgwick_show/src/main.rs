#![deny(unsafe_code)]
#![no_std]

extern crate f3;
extern crate m;
#[macro_use]
extern crate serde_derive;
extern crate embedded_hal as hal;
extern crate madgwick_show;
#[macro_use(block)]
extern crate nb;
extern crate cast;
extern crate madgwick;
use cast::{f32, i32};

use core::f32::consts::PI;
use core::fmt::{self, Write};
use f3::hal::delay::Delay;
use f3::hal::prelude::*;
use f3::hal::stm32f30x::TIM2;
pub use f3::hal::stm32f30x::usart1;
use f3::hal::timer::Timer;
pub use f3::led::Direction;
pub use f3::led::Led;
pub use f3::lsm303dlhc::I16x3;
use f3::lsm303dlhc::{AccelOdr, MagOdr};
use f3::{L3gd20, Lsm303dlhc};
use hal::blocking::delay::DelayMs;
use m::Float;
use madgwick::{F32x3, Marg};
use madgwick_show::aux;
use madgwick_show::aux::Board;
use madgwick_show::messenger::Messenger;

// Number of samples to use for gyroscope calibration
const NSAMPLES: i32 = 256;

const M_BIAS_X: f32 = -53.;
const M_SCALE_X: f32 = 563.0;

const M_BIAS_Y: f32 = -46.;
const M_SCALE_Y: f32 = 583.5;

const M_BIAS_Z: f32 = 1.0;
const M_SCALE_Z: f32 = 543.0;

// Sensitivities of the accelerometer and gyroscope, respectively
const K_G: f32 = 2. / (1 << 15) as f32; // LSB -> g
const K_AR: f32 = 8.75e-3 * PI / 180.; // LSB -> rad/s

// Madgwick filter parameters
//const SAMPLE_FREQ: u32 = 220;
const SAMPLE_FREQ: u32 = 100;
const BETA: f32 = 1e-1;

#[derive(Debug, Serialize)]
enum Message {
    Magnet {
        x: i16,
        y: i16,
        z: i16,
    },
    NormalizedMagnet {
        x: f32,
        y: f32,
        z: f32,
    },
    Magnitude(f32),
    Gyro {
        x: f32,
        y: f32,
        z: f32,
    },
    Accel {
        x: f32,
        y: f32,
        z: f32,
    },
    Quaternion(f32, f32, f32, f32),
    All {
        magnet: (f32, f32, f32),
        gyro: (f32, f32, f32),
        accel: (f32, f32, f32),
    },
    None,
}

fn main() {
    //let (_led, mut _lsm303dlhc, mut _l3gd20, mut delay, mut usart1, mut cm, mut timer) =
    //aux::init();

    let mut board = Board::new();

    //let mut led: Led = _led;
    //let mut lsm303dlhc: Lsm303dlhc = _lsm303dlhc;
    //let mut l3gd20: L3gd20 = _l3gd20;
    //

    let mut led: Led = board.led.take().unwrap();
    let mut lsm303dlhc: Lsm303dlhc = board.mag.take().unwrap();
    let mut l3gd20: L3gd20 = board.gyro.take().unwrap();
    let mut timer = board.timer.take().unwrap();
    let mut usart1 = board.usart1.take().unwrap();
    let mut itm = board.itm.take().unwrap();

    let mut messenger = Messenger::new(itm);

    timer = board.reset_timer(timer, 380.hz());

    let (gbias_x, gbias_y, gbias_z) = calibrate_gyroscope(&mut l3gd20, &mut timer);
    led.on();

    let mut marg = Marg::new(BETA, 1. / f32(SAMPLE_FREQ));
    timer = board.reset_timer(timer, SAMPLE_FREQ.hz());

    loop {
        block!(timer.wait()).unwrap();

        let m = lsm303dlhc.mag().unwrap();
        let ar = l3gd20.gyro().unwrap();
        let g = lsm303dlhc.accel().unwrap();

        let m_x = (f32(m.x) - M_BIAS_X) / M_SCALE_X;
        let m_y = (f32(m.y) - M_BIAS_Y) / M_SCALE_Y;
        let m_z = (f32(m.z) - M_BIAS_Z) / M_SCALE_Z;

        //let magnitude = (m_x * m_x + m_y * m_y + m_z * m_z).sqrt();
        //messenger.send(&Message::Magnitude(magnitude)).unwrap();

        // Fix the X Y Z components of the magnetometer so they match the gyro axes
        let m = F32x3 {
            x: m_y,
            y: -m_x,
            z: m_z,
        };

        let ar_x = f32(ar.x - gbias_x) * K_AR;
        let ar_y = f32(ar.y - gbias_y) * K_AR;
        let ar_z = f32(ar.z - gbias_z) * K_AR;
        let ar = F32x3 {
            x: ar_x,
            y: ar_y,
            z: ar_z,
        };

        // Fix the X Y Z components of the accelerometer so they match the gyro axes
        let g_x = f32(g.x) * K_G;
        let g_y = f32(g.y) * K_G;
        let g_z = f32(g.z) * K_G;
        let g = F32x3 {
            x: g_y,
            y: -g_x,
            z: g_z,
        };

        messenger
            .send(&Message::All {
                magnet: (m.x, m.y, m.z),
                gyro: (ar.x, ar.y, ar.z),
                accel: (g.x, g.y, g.z),
            })
            .unwrap();

        // Run the filter
        let quat = marg.update(m, ar, g);

        messenger
            .send(&Message::Quaternion(quat.0, quat.1, quat.2, quat.3))
            .unwrap();
    }
}

fn calibrate_gyroscope(l3gd20: &mut L3gd20, timer: &mut Timer<TIM2>) -> (i16, i16, i16) {
    // Calibrate the gyroscope
    let mut ar_bias_x = 0;
    let mut ar_bias_y = 0;
    let mut ar_bias_z = 0;
    for _ in 0..NSAMPLES {
        //delay.delay_ms(2_u16);
        block!(timer.wait()).unwrap();

        let ar = l3gd20.gyro().unwrap();

        ar_bias_x += ar.x as i32;
        ar_bias_y += ar.y as i32;
        ar_bias_z += ar.z as i32;
    }
    let ar_bias_x = (ar_bias_x / NSAMPLES) as i16;
    let ar_bias_y = (ar_bias_y / NSAMPLES) as i16;
    let ar_bias_z = (ar_bias_z / NSAMPLES) as i16;

    // Turn on the LED after calibrating the gyroscope

    (ar_bias_x, ar_bias_y, ar_bias_z)
}

#![no_std]

#[macro_use(iprintln, iprint)]
extern crate cortex_m;
extern crate f3;
extern crate stm32f30x;
extern crate stm32f30x_hal as hal;
use hal::delay::Delay;
use hal::gpio::gpiob::Parts;
use hal::gpio::{AF2, Output};
use hal::prelude::*;
use hal::rcc::{APB1, APB2, Clocks, Rcc, AHB, CFGR};
use stm32f30x::{TIM1, TIM4, RCC};
use stm32f30x::{rcc, tim1, tim2};

const ARR: u16 = 39999;
const PSC: u16 = 0;
const DUTY: u16 = 20000;

pub fn main() {
    let cp = cortex_m::Peripherals::take().unwrap();
    let dp = stm32f30x::Peripherals::take().unwrap();
    let mut rcc = dp.RCC.constrain();
    let mut flash = dp.FLASH.constrain();
    let clocks: Clocks = rcc.cfgr.freeze(&mut flash.acr);

    let mut itm = cp.ITM;

    let hclk = clocks.hclk();
    let pclk1 = clocks.pclk1();
    let pclk2 = clocks.pclk2();

    iprintln!(&mut itm.stim[0], "hclk = {:?}", hclk.0);
    iprintln!(&mut itm.stim[0], "pclk1 = {:?}", pclk1.0);
    iprintln!(&mut itm.stim[0], "pclk2 = {:?}", pclk2.0);

    let mut delay = Delay::new(cp.SYST, clocks);
    let mut gpiob = dp.GPIOB.split(&mut rcc.ahb);
    let mut pb9 = gpiob.pb9.into_af2(&mut gpiob.moder, &mut gpiob.afrh);

    /*
    // Set pb9 to AF2
    let offset = 2 * 9;

    // alternate function mode
    let mode = 0b10;
    dp.GPIOB
        .moder
        .modify(|r, w| unsafe { w.bits((r.bits() & !(0b11 << offset)) | (mode << offset)) });

    let af = 2;
    let offset = 4 * (9 % 8);
    dp.GPIOB
        .afrh
        .modify(|r, w| unsafe { w.bits((r.bits() & !(0b1111 << offset)) | (af << offset)) });

    //  Done with GPIO
    */

    // Enable timer
    //let apb1: APB1 = rcc.apb1;
    //apb1.enr().modify(|_, w| w.tim4en().enabled());
    //apb1.rstr().modify(|_, w| w.tim4rst().set_bit());
    //apb1.rstr().modify(|_, w| w.tim4rst().clear_bit());
    //
    //

    /***********
    // Timer 4 with output PWM
     */
    let apb1enr = unsafe { &(*RCC::ptr()).apb1enr };
    apb1enr.modify(|_, w| w.tim4en().enabled());

    let apb1rstr = unsafe { &(*RCC::ptr()).apb1rstr };
    apb1rstr.modify(|_, w| w.tim4rst().set_bit());
    apb1rstr.modify(|_, w| w.tim4rst().clear_bit());

    // Setup timer
    let tim4: &'static tim2::RegisterBlock = unsafe { &*TIM4::ptr() };
    unsafe {
        //prescaler
        tim4.psc.write(|w| w.psc().bits(PSC));
        // autoreload register
        tim4.arr.write(|w| w.arrl().bits(ARR));
        // update generation ?
        tim4.egr.write(|w| w.ug().set_bit());

        //oc4m = 110 значит PWM mode 1. Активный сигнал на совпадении счетчиков
        tim4.ccmr2_output
            .modify(|_, w| w.oc4pe().set_bit().oc4m().bits(0b110));

        // set duty cycle
        tim4.ccr4.write(|w| w.ccr4l().bits(DUTY));

        // CC4P - Active == pin is high
        // cc4e - OC4 signal is output on the corresponding output pin
        tim4.ccer
            .modify(|_, w| w.cc4p().clear_bit().cc4e().set_bit());
        //tim4.cr1.modify(|_, w| w.cen().set_bit());

        tim4.cr1.write(|w| unsafe {
            w.cms()
                .bits(0b00) // align by front
                .dir() // direction up
                .set_bit()
                .opm() // one pulse mode or repeated
                .clear_bit()
                .cen() // запускаем генератор
                .set_bit()
        });
    }

    /***********
    // Timer 1 with input PWM Channel 1
     */

    let mut gpioa = dp.GPIOA.split(&mut rcc.ahb);
    let mut pa8 = gpioa.pa8.into_af6(&mut gpioa.moder, &mut gpioa.afrh);

    let apb2enr = unsafe { &(*RCC::ptr()).apb2enr };
    apb2enr.modify(|_, w| w.tim1en().enabled());

    let apb2rstr = unsafe { &(*RCC::ptr()).apb2rstr };
    apb2rstr.modify(|_, w| w.tim1rst().set_bit());
    apb2rstr.modify(|_, w| w.tim1rst().clear_bit());

    /*
    1. Select the active input for TIMx_CCR1: write the CC1S bits to 01 in the TIMx_CCMR1
    register (TI1 selected).
    2. Select the active polarity for TI1FP1 (used both for capture in TIMx_CCR1 and counter
    clear): write the CC1P to ‘0’ and the CC1NP bit to ‘0’ (active on rising edge).
    3. Select the active input for TIMx_CCR2: write the CC2S bits to 10 in the TIMx_CCMR1
    register (TI1 selected).
    4. Select the active polarity for TI1FP2 (used for capture in TIMx_CCR2): write the CC2P
    bit to ‘1’ and the CC2NP bit to ’0’ (active on falling edge).
    5. Select the valid trigger input: write the TS bits to 101 in the TIMx_SMCR register
    (TI1FP1 selected).
    6. Configure the slave mode controller in reset mode: write the SMS bits to 100 in the
    TIMx_SMCR register.
    7. Enable the captures: write the CC1E and CC2E bits to ‘1 in the TIMx_CCER register.
    */

    // Setup timer
    let t1: &'static tim1::RegisterBlock = unsafe { &*TIM1::ptr() };

    //
    //tim1::CCMR1_INPUT.modify(|_, w| w.cc1s().bits(0b01));

    // CC1P - передний фронт
    // cc1e - захват сигнала
    t1.ccer
        .modify(|_, w| w.cc1p().clear_bit().cc1e().clear_bit());

    loop {
        delay.delay_ms(1000u16);
    }

    //loop {
    //pin.set_high();
    //delay.delay_ms(10u16);
    //pin.set_low();
    //delay.delay_ms(10u16);
    //}
}

//! Examples
//!
//! In order of increasing complexity
// Auto-generated. Do not modify.
pub mod _00_hello;
pub mod _01_led;
pub mod _02_blinky;
pub mod _03_delay;
pub mod _04_serial;
pub mod _05_pwm;
pub mod _06_qei;
pub mod _07_mpu9250;

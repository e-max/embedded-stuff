//! Examples
//!
//! In order of increasing complexity
// Auto-generated. Do not modify.
pub mod _00_hello;
pub mod _01_itm;
pub mod _02_leds;
pub mod _03_blinky;
pub mod _04_roulette;
pub mod _05_serial;
pub mod _06_serial_echo;
pub mod _07_l3gd20;
pub mod _08_lsm303dlhc;
pub mod _09_cooperative;
pub mod _10_reactive_serial_echo;
pub mod _11_reactive_roulette;
pub mod _12_preemptive;
pub mod _13_log_sensors;
pub mod _14_madgwick;

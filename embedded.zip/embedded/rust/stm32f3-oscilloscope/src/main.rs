// stm32f3-oscilloscope - src/main.rs

// A low-bandwidth, digital storage oscilloscope for the STM32F3 Discovery
// development board.

// Copyright © 2017 Sean Bolton
//
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
//
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

// For a summary of the peripherals used, see docs/peripherals.rst

#![feature(core_intrinsics)]
#![feature(used)]
#![no_std]

extern crate cortex_m;
extern crate cortex_m_rt;
extern crate stm32f30x;

mod parallax_8x12_font;
mod st7735;
mod sysclk;

use core::intrinsics::{volatile_load, volatile_store};
use cortex_m::exception;
use cortex_m::peripheral::{SystClkSource, SCB, SYST};
use stm32f30x::{interrupt, DMA1, GPIOD, RCC};

use st7735::*;
use sysclk::set_sys_clock;

// ======== required declarations for Rust and C linkage ========

// the C functions we call from Rust
extern "C" {
    fn _st7735_initR(lcd_type: u8);
    fn _st7735_drawFastHLine(x: i16, y: i16, h: i16, color: u16);
    fn _st7735_drawFastVLine(x: i16, y: i16, h: i16, color: u16);
    fn _st7735_drawPixel(x: i16, y: i16, color: u16);
    fn _st7735_fillScreen(color: u16);
    fn _st7735_setAddrWindow(x0: u8, y0: u8, x1: u8, y1: u8);
    fn _st7735_setRotation(rotation: u8);
    fn _st7735_get_height() -> u8;
    fn _st7735_get_width() -> u8;
}

// the Rust functions in submodules that we call from C
pub use st7735::{lcd_cs0, lcd_cs1, lcd_rst0, lcd_rst1, st7735_fill_rect, st7735_send_cmd,
                 st7735_send_data};

// ======== global (cough) state ========

// signal generator frequencies
struct SiggenFreq {
    frequency: u32,
    label: &'static [u8],
}

// ======== main ========

#[inline(never)]
fn main() {
    // set system clock to 72MHz
    set_sys_clock();

    cortex_m::interrupt::free(|cs| {
        // borrow peripherals
        let rcc = RCC.borrow(cs);
        let syst = SYST.borrow(cs);
        let scb = SCB.borrow(cs);
        let gpiod = GPIOD.borrow(cs);

        // power on GPIOD and GPIOE
        rcc.ahbenr
            .modify(|_, w| w.iopden().enabled().iopeen().enabled());
    });

    // LCD setup
    st7735_setup();
    //delay_ms(50);
    st7735_initR(St7735Type::RedTab as u8);
    st7735_setRotation(3); // landscape
    st7735_fillScreen(St7735Color::Black as u16);
    st7735_print(b"stm-scope", 0, 0, St7735Color::Green, St7735Color::Black);
}

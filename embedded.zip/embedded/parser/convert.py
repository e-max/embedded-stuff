
for l in open("./all.txt"):
    print(",".join([y for x in [z.split("(")[1].split(",")  for z in  l.lstrip("All").strip("{} \n").split(")") if z != ''] for y in x ]))


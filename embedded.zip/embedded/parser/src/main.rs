#![feature(duration_extras)]
extern crate ahrs;
extern crate csv;
extern crate ctrlc;
extern crate kiss3d;
extern crate madgwick;
extern crate nalgebra as na;
extern crate quaternion;
extern crate termion;
extern crate vecmath;

use vecmath::Vector3;

use ahrs::Ahrs;
use ahrs::Madgwick;

use kiss3d::light::Light;
use kiss3d::window::Window;
use madgwick::{F32x3, Marg};
use na::UnitQuaternion;
use std::error::Error;
use std::io;
use std::sync::mpsc::{self, Receiver, Sender, TryRecvError};
use std::thread;
use std::time;

// Madgwick filter parameters
const SAMPLE_FREQ: f32 = 100.0;
const BETA: f32 = 1e-1;

pub fn main() {
    let (mut sender, receiver) = mpsc::channel();
    let parser = thread::spawn(move || {
        parse(&mut sender);
    });
    //let render = thread::spawn(move || {
    //render(receiver);
    //});

    parser.join().unwrap();
    //    render.join().unwrap();
}

fn parse(sender: &mut Sender<(f32, f32, f32, f32)>) {
    ctrlc::set_handler(move || {
        println!("{}", termion::cursor::Show);
    }).expect("Error setting Ctrl-C handler");
    let mut marg = Marg::new(BETA, 1. / SAMPLE_FREQ);
    let mut rdr = csv::Reader::from_reader(io::stdin()).has_headers(false);
    let mut marg2 = Madgwick::new(1. / SAMPLE_FREQ, BETA);
    for result in rdr.records() {
        let record = result.unwrap();
        //for f in record {
        //println!("\x1B[31;1m f\x1B[0m = {:?}", f);
        //}

        let z: Vec<f32> = record
            .iter()
            .map(|x| x.trim().parse::<f32>().unwrap())
            .collect();

        let mag = F32x3 {
            x: z[0],
            y: z[1],
            z: z[2],
        };
        let gyro = F32x3 {
            x: z[3],
            y: z[4],
            z: z[5],
        };
        let accel = F32x3 {
            x: z[6],
            y: z[7],
            z: z[8],
        };

        let gyrov3 = na::Vector3::new(gyro.x, gyro.y, gyro.z);
        let accelv3 = na::Vector3::new(accel.x, accel.y, accel.z);
        let magv3 = na::Vector3::new(mag.x, mag.y, mag.z);

        let q = marg.update(mag, gyro, accel);
        let q2 = marg2.update(&gyrov3, &accelv3, &magv3).unwrap();
        sender.send((q.0, q.1, q.2, q.3)).unwrap();
        let theta = (mag.y as f32).atan2(mag.x as f32);

        //let v = Vector3;
        let qwrap: quaternion::Quaternion<f32> = (q.0, [q.1, q.2, q.3]);
        let res = quaternion::rotate_vector(qwrap, [0.0, 1.0, 0.0]);
        //let resX = quaternion::rotate_vector(qwrap, [1.0, 0.0, 0.0]);

        let theta2 = (res[0] as f32).atan2(res[1] as f32);

        print!(
            "{} Mag =( {:+.3} {:+.3} {:+.3})  Theta = {:+.3}  Q = ({:+.3} {:+.3} {:+.3} {:+.3})  Res = ({:+.3} {:+.3} {:+.3}) Theta2 = {:+.3}\r",
            termion::cursor::Hide,
            mag.x,
            mag.y,
            mag.z,
            theta * 57.2958,
            q.0,
            q.1,
            q.2,
            q.3,
            res[0],
            res[1],
            res[2],
            theta2 * 57.2958,
        );
    }
    println!("\x1B[33;1m \n EXIT\x1B[0m");
}

fn render(receiver: Receiver<(f32, f32, f32, f32)>) {
    let mut window = Window::new("Quaternion visualizer");
    let mut c = window.add_cube(0.3, 0.01, 0.2);
    c.set_color(0.0, 1.0, 0.0);
    window.set_light(Light::StickToCamera);

    let mut last: Option<(f32, f32, f32, f32)> = None;

    let mut now = time::Instant::now();

    while window.render() {
        //loop {
        //match receiver.try_recv() {
        //Ok(q) => last = Some(q),
        //Err(TryRecvError::Empty) => break,
        //Err(TryRecvError::Disconnected) => return,
        //}
        //}
        //
        last = Some(receiver.recv().unwrap());

        if let Some(q) = last {
            // NOTE In kiss3d the coordinate axes look like this
            //
            //      ^ Y
            //      |
            // X    |
            // <----X Z
            //
            // whereas the gyroscope axes on the F3 look like this
            //
            //   ^ Z
            //   |
            //   |
            // X o----> Y
            //
            // when the USB connectors are facing in that +Y way
            //println!("\x1B[31;1m q\x1B[0m = {:?}", q);
            c.set_local_rotation(UnitQuaternion::from_quaternion(na::Quaternion::new(
                q.0,
                -q.2, // -y
                q.3,  // +z
                -q.1, // -x
            )));
        }
    }
}

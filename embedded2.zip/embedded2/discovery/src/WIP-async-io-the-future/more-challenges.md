# More challenges

- Respond `"OK"` every time the spin direction of the LED roulette is changed.
- Bring back the echo server. The `"reverse"` command must still work though.
- Print back an error message when your receive buffer gets full.

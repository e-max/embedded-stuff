# macOS

All the tools can be install using [Homebrew]:

[Homebrew]: http://brew.sh/

``` console
$ # Arm GCC toolchain
$ brew tap ArmMbed/homebrew-formulae
$ brew install arm-none-eabi-gcc

$ # Minicom and OpenOCD
$ brew install minicom openocd
```

That's all! Go to the [next section].

[next section]: verify.md

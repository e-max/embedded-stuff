#![deny(unsafe_code)]
#![no_main]
#![no_std]

use aux5::{entry, prelude::*, Delay, Leds};

#[entry]
fn main() -> ! {
    let (mut delay, mut leds): (Delay, Leds) = aux5::init();
    let half_period = 50_u16;

    leds[0].on();
    loop {
        for i in 0..16 {
            if i % 2 == 0 {
                let mut lednum = i / 2 + 1;
                if lednum > 7 {
                    lednum = 0
                }
                leds[lednum].on();
            } else {
                let mut lednum = i / 2;
                if lednum > 7 {
                    lednum = 0
                }
                leds[lednum].off();
            }
            delay.delay_ms(half_period);
        }
    }
}

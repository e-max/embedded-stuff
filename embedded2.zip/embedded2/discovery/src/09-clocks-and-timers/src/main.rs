#![no_main]
#![no_std]

use cortex_m::{iprint, iprintln};

use aux9::{bkpt, entry, tim6};

#[inline(never)]
fn delay(tim6: &tim6::RegisterBlock, ms: u16) {
    tim6.arr.write(|w| w.arr().bits(ms));
    tim6.cr1.write(|w| w.cen().enabled());
    while !tim6.sr.read().uif().bit_is_set() {}

    tim6.sr.write(|w| w.uif().clear_bit());
}

#[entry]
fn main() -> ! {
    let (mut leds, rcc, tim6, itm) = aux9::init();

    rcc.apb1enr.write(|w| w.tim6en().enabled());

    tim6.cr1.write(|w| {
        w.cen().disabled();
        w.opm().one_pulse()
    });
    tim6.psc.write(|w| w.psc().bits(7_999));

    // TODO initialize TIM6

    let ms = 50;
    loop {
        for curr in 0..8 {
            let next = (curr + 1) % 8;

            leds[next].on();
            delay(tim6, ms);
            leds[curr].off();
            delay(tim6, ms);
        }
    }
}

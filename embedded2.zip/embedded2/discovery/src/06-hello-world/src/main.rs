#![deny(unsafe_code)]
#![no_main]
#![no_std]

#[allow(unused_imports)]
use aux6::{entry, iprint, iprintln};

#[entry]
fn main() -> ! {
    let mut itm = aux6::init();

    iprintln!(
        &mut itm.stim[0],
        "world 1234567890 ABCDEFGHIJKLMNOPQRSTUVWXYZ!"
    );
    iprintln!(&mut itm.stim[0], "1234567890 ABCDEFGHIJKLMNOPQRSTUVWXYZ!");
    loop {}
}

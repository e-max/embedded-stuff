#![no_main]
#![no_std]

//! Подключи PA7 !!!

#[allow(unused_extern_crates)] // NOTE(allow) bug rust-lang/rust53964
extern crate panic_itm; // panic handler

use nb::block;

use cortex_m;
use cortex_m::{asm::bkpt, iprint, iprintln, peripheral::ITM};
pub use cortex_m_rt::entry;

use stm32f3xx_hal::delay::Delay;
use stm32f3xx_hal::prelude::*;
use stm32f3xx_hal::spi::Spi;
use stm32f3xx_hal::stm32;
use stm32f3xx_hal::timer::Timer;

use smart_leds::{brightness, gamma, SmartLedsWrite, RGB8};
use ws2812_spi::Ws2812;

use embedded_graphics::fonts::{Font8x16, Text};
use embedded_graphics::image::Image;
use embedded_graphics::pixelcolor::{PixelColor, Rgb888};
use embedded_graphics::prelude::*;
use embedded_graphics::style::{TextStyle, TextStyleBuilder};
use led::wsdisplay::WsDisplay;
use tinybmp::Bmp;

#[entry]
fn main() -> ! {
    let cp = cortex_m::Peripherals::take().unwrap();
    let mut itm: ITM = cp.ITM;

    let dp = stm32::Peripherals::take().unwrap();

    let mut flash = dp.FLASH.constrain();
    let mut rcc = dp.RCC.constrain();
    let clocks = rcc
        .cfgr
        .sysclk(64.mhz())
        .pclk1(32.mhz())
        .freeze(&mut flash.acr);

    let mut gpioa = dp.GPIOA.split(&mut rcc.ahb);

    // Configure pins for SPI
    let sck = gpioa.pa5.into_af5(&mut gpioa.moder, &mut gpioa.afrl);
    let miso = gpioa.pa6.into_af5(&mut gpioa.moder, &mut gpioa.afrl);
    let mosi = gpioa.pa7.into_af5(&mut gpioa.moder, &mut gpioa.afrl);

    // Configure SPI with 3Mhz rate

    let mut spi = Spi::spi1(
        dp.SPI1,
        (sck, miso, mosi),
        ws2812_spi::MODE,
        3.mhz(),
        clocks,
        &mut rcc.apb2,
    );

    let mut ws = Ws2812::new(spi);

    iprintln!(&mut itm.stim[0], "blah blah blah");

    let mut delay = Delay::new(cp.SYST, clocks);

    let mut display = WsDisplay::new();

    let style = TextStyleBuilder::new(Font8x16)
        .text_color(Rgb888::YELLOW)
        .background_color(Rgb888::BLACK)
        .build();

    // Create a text at position (20, 30) and draw it using the previously defined style
    Text::new("K", Point::new(0, 0))
        .into_styled(style)
        .draw(&mut display)
        .unwrap();

    ws.write(display.0.iter().cloned()).unwrap();
    sleep(&mut delay, 2000);

    display.reset();

    // Create a text at position (20, 30) and draw it using the previously defined style
    Text::new("A", Point::new(8, 0))
        .into_styled(style)
        .draw(&mut display)
        .unwrap();

    ws.write(display.0.iter().cloned()).unwrap();
    sleep(&mut delay, 2000);

    // black
    display.reset();
    ws.write(display.0.iter().cloned()).unwrap();
    sleep(&mut delay, 500);

    // Create a text at position (20, 30) and draw it using the previously defined style
    Text::new("KA", Point::new(0, 0))
        .into_styled(style)
        .draw(&mut display)
        .unwrap();

    ws.write(display.0.iter().cloned()).unwrap();
    sleep(&mut delay, 500);

    // black
    display.reset();
    ws.write(display.0.iter().cloned()).unwrap();
    sleep(&mut delay, 500);

    // Create a text at position (20, 30) and draw it using the previously defined style
    Text::new("KA", Point::new(0, 0))
        .into_styled(style)
        .draw(&mut display)
        .unwrap();

    ws.write(display.0.iter().cloned()).unwrap();
    sleep(&mut delay, 500);

    // black
    display.reset();
    ws.write(display.0.iter().cloned()).unwrap();
    sleep(&mut delay, 500);

    // Create a text at position (20, 30) and draw it using the previously defined style
    Text::new("XA", Point::new(0, 0))
        .into_styled(style)
        .draw(&mut display)
        .unwrap();

    ws.write(display.0.iter().cloned()).unwrap();
    sleep(&mut delay, 2000);

    let bmp = Bmp::from_slice(include_bytes!("../poo2.bmp")).unwrap();

    let image: Image<Bmp, Rgb888> = Image::new(&bmp, Point::zero());

    image.draw(&mut display).unwrap();
    ws.write(display.0.iter().cloned()).unwrap();
    //ws.write(brightness(gamma(display.0.iter().cloned()), 32))
    //.unwrap();
    delay.delay_ms(10 as u16);

    loop {
        //ws.write(empty.iter().cloned()).unwrap();
        //delay.delay_ms(100 as u16);
    }
}

fn sleep(delay: &mut Delay, ms: u32) {
    for _ in 0..(ms / 100) {
        delay.delay_ms(100 as u16);
    }
}

use core::convert::TryInto;
use core::fmt::Debug;
use embedded_graphics::pixelcolor::Rgb888;
use embedded_graphics::prelude::*;
use embedded_graphics::DrawTarget;
use smart_leds::RGB8;

pub struct WsDisplay(pub [RGB8; 256]);

impl WsDisplay {
    pub fn new() -> Self {
        WsDisplay([RGB8::default(); 256])
    }

    pub fn reset(&mut self) {
        for i in 0..256 {
            self.0[i] = RGB8 { r: 0, g: 0, b: 0 };
        }
    }

    fn index(&self, x: u8, y: u8) -> usize {
        let index: u16 = if x % 2 == 0 {
            x as u16 * 16 + y as u16
        } else {
            (x as u16 + 1) * 16 - y as u16 - 1
        };
        let idx = index as usize;
        idx
    }
}

impl Debug for WsDisplay {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        write!(f, "##################\n");
        for y in 0..16 {
            write!(f, "#");
            for x in 0..16 {
                let idx = self.index(x, y);
                let px = self.0[self.index(x, y)];
                if px.r as u32 + px.g as u32 + px.b as u32 > 0 {
                    write!(f, "x")?;
                } else {
                    write!(f, " ")?;
                }
                //write!(f, "{}", self.0[self.index(x, y)])?;
            }
            write!(f, "#");
            write!(f, "\n")?;
        }
        write!(f, "##################\n");
        Ok(())
    }
}

impl DrawTarget<Rgb888> for WsDisplay {
    type Error = &'static str;
    //type Error = core::convert::Infallible;

    fn draw_pixel(&mut self, pixel: Pixel<Rgb888>) -> Result<(), Self::Error> {
        let Pixel(coord, color) = pixel;
        if let Ok((x @ 0..=15, y @ 0..=15)) = coord.try_into() {
            self.0[self.index(x as u8, y as u8)] = RGB8 {
                r: color.r(),
                g: color.g(),
                b: color.b(),
            };
        }

        Ok(())
    }
    fn size(&self) -> Size {
        Size {
            width: 16,
            height: 16,
        }
    }
}

use std::time::Instant;

use criterion::{black_box, criterion_group, criterion_main, Criterion};

fn time() -> u64 {
    let t = Instant::now();
    let mut e = 0;
    for _i in 0..1000 {
        e = t.elapsed().as_secs();
    }
    e
}

fn criterion_benchmark(c: &mut Criterion) {
    c.bench_function("time 1000", |b| b.iter(|| time()));
}

criterion_group!(benches, criterion_benchmark);
criterion_main!(benches);

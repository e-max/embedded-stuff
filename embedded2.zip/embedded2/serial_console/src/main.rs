use std::convert::From;
use std::env;
use std::fmt::Debug;
use std::time::{Duration, Instant};

use linefeed::{Interface, ReadResult, Terminal};

use postcard::{self, from_bytes_cobs, to_slice_cobs};
use serde::{Deserialize, Serialize};

use mio_serial::{DataBits, FlowControl, Parity, Serial, SerialPortSettings, StopBits};

use smol::{self, Async};

use futures::future;
use futures::io::{AsyncBufReadExt, AsyncRead, AsyncWrite, AsyncWriteExt, BufReader};

enum Baudrate {
    Low = 115_200,
    Middle = 921_600,
    High = 1_843_200,
}

#[derive(Serialize, Deserialize, Debug)]
enum Message {
    Msg(String),
    Coord { x: u32, y: u32 },
    List(Vec<u8>),
    U32(u32),
}

const SETTINGS: SerialPortSettings = mio_serial::SerialPortSettings {
    baud_rate: Baudrate::Low as u32,
    data_bits: DataBits::Eight,
    parity: Parity::None,
    stop_bits: StopBits::One,
    flow_control: FlowControl::None,
    timeout: Duration::from_secs(3600),
};

fn main() -> Result<(), Error> {
    let path = env::args().nth(1).expect("Expected path to serial device");
    // Open the first serialport available.
    let portw_ = Serial::from_path(&path, &SETTINGS).expect("Failed to open serial port");

    let portw = piper::Arc::new(Async::new(portw_).unwrap());
    let portr = portw.clone();

    let (tx, rx) = piper::chan::<Message>(100);

    let interface = piper::Arc::new(Interface::new("async-demo")?);
    interface.set_prompt("async-demo> ")?;

    let iface = interface.clone();

    smol::Task::spawn(async { async_write_usart(iface, portw, rx).await })
        .unwrap()
        .detach();

    let iface = interface.clone();
    smol::Task::spawn(async { async_read_usart(iface, portr).await })
        .unwrap()
        .detach();

    smol::Task::blocking(async { cli(interface, tx).await })
        .unwrap()
        .detach();

    smol::run(future::pending::<()>());
    Ok(())
}

async fn cli<T: Terminal>(
    interface: piper::Arc<Interface<T>>,
    tx: piper::Sender<Message>,
) -> Result<(), Error> {
    while let ReadResult::Input(input) = interface.read_line()? {
        writeln!(interface, "got input {:?}", input).unwrap();
        interface.add_history_unique(input.clone());

        match serde_json::from_str(&input) {
            Ok(m) => {
                tx.send(m).await;
            }
            Err(e) => {
                writeln!(interface, "cannot parse command {:?}", e).unwrap();
            }
        }
    }
    Ok(())
}

async fn async_write_usart<T: Terminal>(
    term: piper::Arc<Interface<T>>,
    mut port: impl AsyncWrite + Unpin,
    rx: piper::Receiver<Message>,
) -> Result<(), Error> {
    writeln!(term, "Start writer").unwrap();
    let mut buf: [u8; 512] = [0; 512];

    while let Some(msg) = rx.recv().await {
        writeln!(term, "try to send msg = {:?}", msg).unwrap();
        let used = to_slice_cobs(&msg, &mut buf[..])?;
        port.write_all(&used).await?;
    }
    Ok(())
}

async fn async_read_usart<T: Terminal>(
    term: piper::Arc<Interface<T>>,
    port: impl AsyncRead + Unpin,
) -> Result<(), Error> {
    writeln!(term, "start reader").unwrap();
    //let mut pool = Pool::with_capacity(5, 0, || Vec::with_capacity(512));
    let mut reader = BufReader::new(port);
    let mut vec: Vec<u8> = Vec::with_capacity(512);

    let mut n = 0;
    loop {
        vec.clear();
        reader.read_until(0u8, &mut vec).await?;
        match from_bytes_cobs::<Message>(vec.as_mut_slice()) {
            Ok(msg) => {
                writeln!(term, "msg = {:?}", msg).unwrap();
            }
            Err(e) => {
                writeln!(term, "Couldn't deserialize {:?} : {:?}", vec, e).unwrap();
            }
        }
        {}
    }
}

#[derive(Debug)]
struct Error(String);

impl From<std::io::Error> for Error {
    fn from(e: std::io::Error) -> Self {
        Error(format!("{:?}", e))
    }
}

impl From<postcard::Error> for Error {
    fn from(e: postcard::Error) -> Self {
        Error(format!("{:?}", e))
    }
}

pub struct Counter {
    buckets: [u64; 11],
    current: usize,
    start: Instant,
}

impl Counter {
    pub fn new() -> Self {
        Self {
            buckets: [0; 11],
            current: 0,
            start: Instant::now(),
        }
    }
    pub fn add(&mut self, v: u64) {
        let current = (self.start.elapsed().as_secs() % 11) as usize;
        if current != self.current {
            self.current = current;
            self.buckets[self.current] = 0;
        }
        self.buckets[self.current] += v;
    }

    pub fn avg(&self) -> f64 {
        self.buckets
            .iter()
            .enumerate()
            .filter(|(i, _)| *i != self.current)
            .fold(0, |sum, (_, v)| sum + v) as f64
            / 10.0
    }
}

#[cfg(test)]
mod tests {
    use crate::Counter;
    use std::thread;
    use std::time::Duration;
    #[test]
    fn test_counters() {
        let mut counter = Counter::new();
        counter.buckets = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 9999];
        counter.current = 10;

        assert_eq!(counter.avg(), 5.5);
    }
}

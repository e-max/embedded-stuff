#![no_main]
#![no_std]

#[allow(unused_imports)] // NOTE(allow) bug rust-lang/rust53964
use panic_itm; // panic handler

use core::cell::RefCell;
use cortex_m::interrupt::Mutex;

#[macro_use]
extern crate lazy_static;

use cortex_m;
use cortex_m_rt::entry;
use stm32f3::stm32f303;
use stm32f3::stm32f303::interrupt;

use embedded_hal::digital::v2::{InputPin, OutputPin};

use stm32f3xx_hal::gpio::GpioExt;
use stm32f3xx_hal::gpio::{gpioa, gpioe, Input, Output, PullDown, PushPull};
use stm32f3xx_hal::rcc::RccExt;

lazy_static! {
    static ref MUTEX_GPIOA: Mutex<RefCell<Option<gpioa::PA0<Input<PullDown>>>>> =
        Mutex::new(RefCell::new(None));
    static ref MUTEX_PE9: Mutex<RefCell<Option<gpioe::PE9<Output<PushPull>>>>> =
        Mutex::new(RefCell::new(None));
    static ref MUTEX_EXTI: Mutex<RefCell<Option<stm32f303::EXTI>>> = Mutex::new(RefCell::new(None));
}

#[entry]
fn main() -> ! {
    let cp = cortex_m::Peripherals::take().unwrap();
    let dp = stm32f303::Peripherals::take().unwrap();

    dp.RCC.ahbenr.write(|w| w.iopaen().enabled());
    dp.RCC.apb2enr.write(|w| w.syscfgen().enabled());

    let mut rcc = dp.RCC.constrain();

    let mut gpioe = dp.GPIOE.split(&mut rcc.ahb);
    let mut pe9 = gpioe
        .pe9
        .into_push_pull_output(&mut gpioe.moder, &mut gpioe.otyper);

    let mut gpioa = dp.GPIOA.split(&mut rcc.ahb);

    let mut exti = dp.EXTI;

    let pa0 = gpioa
        .pa0
        .into_pull_down_input(&mut gpioa.moder, &mut gpioa.pupdr);

    unsafe {
        dp.SYSCFG.exticr1.write(|w| w.exti0().bits(0b000));
    }

    exti.imr1.modify(|_, w| w.mr0().set_bit());
    exti.rtsr1.modify(|_, w| w.tr0().set_bit());

    cortex_m::interrupt::free(|cs| {
        MUTEX_GPIOA.borrow(cs).replace(Some(pa0));
        MUTEX_PE9.borrow(cs).replace(Some(pe9));
        MUTEX_EXTI.borrow(cs).replace(Some(exti))
    });

    let mut nvic = cp.NVIC;
    nvic.enable(stm32f303::Interrupt::EXTI0);

    loop {}
}

#[interrupt]
fn EXTI0() {
    cortex_m::interrupt::free(|cs| {
        // enter critical section
        let exti = MUTEX_EXTI.borrow(cs).borrow(); // acquire Mutex
        exti.as_ref()
            .unwrap() // unwrap RefCell
            .pr1
            .modify(|_, w| w.pr0().set_bit()); // clear the EXTI line 0 pending bit
    });

    let button_state = cortex_m::interrupt::free(|cs| {
        let mut pe9 = MUTEX_PE9.borrow(cs).borrow_mut(); // acquire Mutex
        pe9.as_mut().unwrap().set_high();

        // enter critical section
        let pa0 = MUTEX_GPIOA.borrow(cs).borrow(); // acquire Mutex
        pa0.as_ref()
            .unwrap() // unwrap RefCell
            .is_high()
    });

    // do something with button_state
}

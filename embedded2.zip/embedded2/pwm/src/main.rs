#![no_main]
#![no_std]

#[allow(unused_extern_crates)] // NOTE(allow) bug rust-lang/rust53964
extern crate panic_itm; // panic handler

use cortex_m;
use cortex_m::{asm::bkpt, iprint, iprintln, peripheral::ITM};
pub use cortex_m_rt::entry;

use embedded_hal::PwmPin;
use stm32f3::stm32f303;
use stm32f3::stm32f303::rcc;
use stm32f3::stm32f303::{RCC, TIM3, TIM4};
use stm32f3xx_hal::flash::FlashExt;
use stm32f3xx_hal::gpio::GpioExt;
use stm32f3xx_hal::pwm::{tim3, tim4};
use stm32f3xx_hal::rcc::RccExt;
use stm32f3xx_hal::time::U32Ext;

unsafe fn init() -> &'static rcc::RegisterBlock {
    return &(*RCC::ptr());
}

fn enable_ch1() {
    unsafe {
        (*TIM3::ptr()).ccer.modify(|_, w| w.cc1e().set_bit());
    }
}

fn disable_ch1() {
    unsafe {
        (*TIM3::ptr()).ccer.modify(|_, w| w.cc1e().set_bit());
    }
}

fn get_max_duty() -> u16 {
    unsafe { (*TIM3::ptr()).arr.read().arr().bits() }
}

fn get_duty() -> u16 {
    unsafe { (*TIM3::ptr()).ccr1.read().ccr().bits() }
}

fn set_duty(duty: u16) -> () {
    unsafe {
        (*TIM3::ptr()).ccr1.modify(|_, w| w.ccr().bits(duty));
    }
}

#[entry]
fn main() -> ! {
    let res = 1000;
    let freq = 100.hz();

    let cp = cortex_m::Peripherals::take().unwrap();
    let mut itm: ITM = cp.ITM;

    let dp = stm32f303::Peripherals::take().unwrap();

    let mut flash = dp.FLASH.constrain();
    let mut rcc = dp.RCC.constrain();
    let clocks = rcc.cfgr.sysclk(8.mhz()).freeze(&mut flash.acr);

    let mut gpioa = dp.GPIOA.split(&mut rcc.ahb);
    let pa6 = gpioa.pa6.into_af2(&mut gpioa.moder, &mut gpioa.afrl);

    let mut gpiob = dp.GPIOB.split(&mut rcc.ahb);
    let pb6 = gpiob.pb6.into_af2(&mut gpiob.moder, &mut gpiob.afrl);

    let (c1_no_pins, _, _, _) = tim3(dp.TIM3, res, freq, &clocks);
    let mut c1 = c1_no_pins.output_to_pa6(pa6);

    c1.set_duty(1);
    c1.enable();
    iprintln!(&mut itm.stim[0], "max duty {:?}", c1.get_max_duty());

    let (t4c1_no_pins, _, _, _) = tim4(dp.TIM4, res, freq, &clocks);
    let mut t4c1 = t4c1_no_pins.output_to_pb6(pb6);

    unsafe {
        (*TIM4::ptr()).ccmr1_input().modify(|_, w| {
            w
                // Select PWM Mode 1 for CHy
                .oc1m()
                .bits(0b0110)
                // set pre-load enable so that updates to the duty cycle
                // propagate but _not_ in the middle of a cycle.
                .oc1pe()
                .set_bit()
        });
    }

    //unsafe {
    //(*TIM4::ptr()).ccmr1_input().modify(|_, w| {
    //w
    //// Select PWM Mode 1 for CHy
    //.oc1m()
    //.bits(0b0110)
    //// set pre-load enable so that updates to the duty cycle
    //// propagate but _not_ in the middle of a cycle.
    //.oc1pe()
    //.set_bit()
    //});
    //}

    // set duty
    unsafe {
        (*TIM4::ptr()).ccr1.modify(|_, w| w.ccr().bits(10));
    }

    // enable channel
    unsafe {
        (*TIM4::ptr()).ccer.modify(|_, w| w.cc1e().set_bit());
    }

    //set_duty(1);
    //enable_ch1();

    /*


    // Power the timer and reset it to ensure a clean state
    // We use unsafe here to abstract away this implementation detail
    // Justification: It is safe because only scopes with mutable references
    // to TIMx should ever modify this bit.
    //
    unsafe {
        (*RCC::ptr()).apb1enr.modify(|_, w| w.tim3en().set_bit());
        (*RCC::ptr()).apb1rstr.modify(|_, w| w.tim3rst().set_bit());
        (*RCC::ptr())
            .apb1rstr
            .modify(|_, w| w.tim3rst().clear_bit());
    }

    //// enable auto reload preloader
    dp.TIM3.cr1.modify(|_, w| w.arpe().set_bit());

    // Set the "resolution" of the duty cycle (ticks before restarting at 0)
    //

    iprintln!(&mut itm.stim[0], "set arr {}", res);
    dp.TIM3.arr.write(|w| unsafe { w.arr().bits(res) });

    // Set the pre-scaler
    // TODO: This is repeated in the timer/pwm module.
    // It might make sense to move into the clocks as a crate-only property.
    // TODO: ppre1 is used in timer.rs (never ppre2), should this be dynamic?
    let clock_freq = clocks.pclk1().0;
    iprintln!(&mut itm.stim[0], "Clock frequency {}", clock_freq);

    let prescale_factor = clock_freq / res as u32 / freq.0;

    iprintln!(
        &mut itm.stim[0],
        "set prescale factor {}",
        prescale_factor - 1
    );
    // NOTE(write): uses all bits of this register.
    dp.TIM3
        .psc
        .write(|w| w.psc().bits(prescale_factor as u16 - 1));

    // Make the settings reload immediately
    // NOTE(write): write to a state-less register.
    dp.TIM3.egr.write(|w| w.ug().set_bit());

    // Enable outputs (STM32 Break Timer Specific)

    // Enable the Timer
    dp.TIM3.cr1.modify(|_, w| w.cen().set_bit());

    unsafe {
        (*TIM3::ptr()).ccmr1_output().modify(|_, w| {
            w
                // Select PWM Mode 1 for CHy
                .oc1m()
                .bits(0b0110)
                // set pre-load enable so that updates to the duty cycle
                // propagate but _not_ in the middle of a cycle.
                .oc1pe()
                .set_bit()
        });
    }

    set_duty(1);
    enable_ch1();
    */

    iprintln!(&mut itm.stim[0], "Hello, world!");
    loop {}
}

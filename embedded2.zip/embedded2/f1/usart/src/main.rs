#![no_main]
#![no_std]
//extern crate panic_itm; // panic handler
//
//

use core::mem::MaybeUninit;
use cortex_m_semihosting::hprintln;
use panic_semihosting as _;

use cortex_m;
use cortex_m_rt::entry;

use embedded_hal::digital::v2::InputPin;
use stm32f1xx_hal::delay::Delay;
use stm32f1xx_hal::gpio::ExtiPin;
use stm32f1xx_hal::gpio::{Edge, Floating, Input, Output, PushPull, Pxx};
use stm32f1xx_hal::pac::{interrupt, Interrupt, NVIC, TIM2};
use stm32f1xx_hal::prelude::*;
use stm32f1xx_hal::pwm_input::*;
use stm32f1xx_hal::serial::{Config, Serial};
use stm32f1xx_hal::stm32;
use stm32f1xx_hal::timer::{Tim1NoRemap, Timer};

use embedded_hal::digital::v2::OutputPin;

use nb::block;

use postcard::{self, from_bytes_cobs, to_slice_cobs};
use serde::{Deserialize, Serialize};

static mut LED: MaybeUninit<stm32f1xx_hal::gpio::gpioc::PC13<Output<PushPull>>> =
    MaybeUninit::uninit();
static mut INT_PIN: MaybeUninit<stm32f1xx_hal::gpio::gpioa::PA9<Input<Floating>>> =
    MaybeUninit::uninit();

static mut TIMER: MaybeUninit<stm32f1xx_hal::timer::CountDownTimer<TIM2>> = MaybeUninit::uninit();
static mut DISTANCE: u32 = 0;

#[interrupt]
fn EXTI9_5() {
    let led = unsafe { &mut *LED.as_mut_ptr() };
    let int_pin = unsafe { &mut *INT_PIN.as_mut_ptr() };
    let timer = unsafe { &mut *TIMER.as_mut_ptr() };

    if int_pin.check_interrupt() {
        led.toggle().unwrap();
        if int_pin.is_high().unwrap() {
            timer.reset();
        } else {
            unsafe {
                DISTANCE = timer.micros_since();
            }
        }

        // if we don't clear this bit, the ISR would trigger indefinitely
        int_pin.clear_interrupt_pending_bit();
    }
}

#[entry]
fn main() -> ! {
    let cp = cortex_m::Peripherals::take().unwrap();
    let dp = stm32::Peripherals::take().unwrap();

    let mut flash = dp.FLASH.constrain();
    let mut rcc = dp.RCC.constrain();
    //let clocks = rcc.cfgr.freeze(&mut flash.acr);
    let clocks = rcc
        .cfgr
        .use_hse(8.mhz())
        .sysclk(72.mhz())
        .pclk1(36.mhz())
        .freeze(&mut flash.acr);
    //hprintln!("sysclk freq: {}", clocks.sysclk().0).unwrap();

    let mut delay = Delay::new(cp.SYST, clocks);

    // Prepare the alternate function I/O registers
    let mut afio = dp.AFIO.constrain(&mut rcc.apb2);

    {
        let timer = unsafe { &mut *TIMER.as_mut_ptr() };
        *timer = Timer::tim2(dp.TIM2, &clocks, &mut rcc.apb1).start_count_down(1.hz());
    }

    // prepare pa8 pa9
    let mut gpioa = dp.GPIOA.split(&mut rcc.apb2);

    let mut pa8 = gpioa.pa8.into_push_pull_output(&mut gpioa.crh);
    let mut pa9 = gpioa.pa9.into_floating_input(&mut gpioa.crh);
    let mut gpioc = dp.GPIOC.split(&mut rcc.apb2);

    {
        let led = unsafe { &mut *LED.as_mut_ptr() };
        *led = gpioc.pc13.into_push_pull_output(&mut gpioc.crh);

        led.toggle().unwrap();

        led.toggle().unwrap();

        led.toggle().unwrap();

        let int_pin = unsafe { &mut *INT_PIN.as_mut_ptr() };
        *int_pin = pa9;
        int_pin.make_interrupt_source(&mut afio);
        int_pin.trigger_on_edge(&dp.EXTI, Edge::RISING_FALLING);
        int_pin.enable_interrupt(&dp.EXTI);
    }

    unsafe {
        NVIC::unmask(Interrupt::EXTI9_5);
    }

    // Configure pb0, pb1 as an analog input
    let mut gpiob = dp.GPIOB.split(&mut rcc.apb2);

    // USART3
    // Configure pb10 as a push_pull output, this will be the tx pin
    let tx = gpiob.pb10.into_alternate_push_pull(&mut gpiob.crh);
    // Take ownership over pb11
    let rx = gpiob.pb11;

    // Set up the usart device. Taks ownership over the USART register and tx/rx pins. The rest of
    // the registers are used to enable and configure the device.
    let serial = Serial::usart3(
        dp.USART3,
        (tx, rx),
        &mut afio.mapr,
        Config::default().baudrate(115200.bps()),
        clocks,
        &mut rcc.apb1,
    );

    let (mut tx, mut rx) = serial.split();
    let mut buf: [u8; 512] = [0; 512];
    let mut msg: Message;
    loop {
        // Split the serial struct into a receiving and a transmitting part

        pa8.set_high().unwrap();
        delay.delay_us(5 as u16);
        pa8.set_low().unwrap();
        delay.delay_ms(1000 as u16);

        unsafe {
            let distance = DISTANCE;
            let a = 32;
            msg = Message::U32(distance / 58);
        }

        let used = to_slice_cobs(&msg, &mut buf[..]).unwrap();
        //tx.write(used).unwrap();
        //

        used.iter()
            .try_for_each(|c| nb::block!(tx.write(*c)))
            .map_err(|_| core::fmt::Error)
            .unwrap();

        delay.delay_ms(1000 as u16);
    }
}

#[derive(Serialize, Deserialize, Debug)]
enum Message {
    Msg(&'static str),
    Coord { x: u32, y: u32 },
    List(&'static [u8]),
    U32(u32),
}

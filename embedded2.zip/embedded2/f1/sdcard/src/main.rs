#![no_main]
#![no_std]
//extern crate panic_itm; // panic handler
//

use cortex_m_semihosting::hprintln;
use panic_semihosting as _;

use cortex_m;
use cortex_m_rt::entry;
use stm32f1xx_hal::adc;
use stm32f1xx_hal::delay::Delay;
use stm32f1xx_hal::prelude::*;
use stm32f1xx_hal::spi::{Mode, Phase, Polarity, Spi};
use stm32f1xx_hal::stm32;

use embedded_hal::digital::v2::OutputPin;

use embedded_sdmmc::SdMmcSpi;

#[entry]
fn main() -> ! {
    let cp = cortex_m::Peripherals::take().unwrap();
    let dp = stm32::Peripherals::take().unwrap();

    let mut flash = dp.FLASH.constrain();
    let mut rcc = dp.RCC.constrain();

    let clocks = rcc
        .cfgr
        .use_hse(8.mhz())
        .sysclk(72.mhz())
        .pclk1(36.mhz())
        .freeze(&mut flash.acr);

    hprintln!("sysclk freq: {}", clocks.sysclk().0).unwrap();
    hprintln!("adc freq: {}", clocks.adcclk().0).unwrap();

    let mut afio = dp.AFIO.constrain(&mut rcc.apb2);

    let mut gpioa = dp.GPIOA.split(&mut rcc.apb2);
    let mut gpiob = dp.GPIOB.split(&mut rcc.apb2);

    let sck = gpioa.pa5.into_alternate_push_pull(&mut gpioa.crl);
    let miso = gpioa.pa6.into_floating_input(&mut gpioa.crl);
    let mosi = gpioa.pa7.into_alternate_push_pull(&mut gpioa.crl);

    let cs = gpiob.pb11.into_push_pull_output(&mut gpiob.crh);

    let spi = Spi::spi1(
        dp.SPI1,
        (sck, miso, mosi),
        &mut afio.mapr,
        Mode {
            polarity: Polarity::IdleLow,
            phase: Phase::CaptureOnFirstTransition,
        },
        200.khz(),
        clocks,
        &mut rcc.apb2,
    );

    let mut sd = SdMmcSpi::new(spi, cs);
    let res = sd.init();
    hprintln!("Init {:?}", res).unwrap();

    let size = sd.card_size_bytes();
    hprintln!("Size {:?}", size).unwrap();

    loop {}
}

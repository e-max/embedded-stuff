use core::fmt::Debug;
use core::ops::{Index, IndexMut};

use stm32f1xx_hal::dma::{self, Transfer};
use stm32f1xx_hal::prelude::*;
use stm32f1xx_hal::serial::{RxDma3, TxDma3};

use heapless::{consts::U256, Vec};
use postcard::{self, flavors::Cobs, flavors::SerFlavor, from_bytes_cobs, serialize_with_flavor};

use as_slice::AsSlice;

use crate::messages::Message;

const DMA_RX_BUF_SIZE: usize = 8;
const DMA_TX_BUF_SIZE: usize = 256;

struct Buffer {
    buf: [u8; DMA_TX_BUF_SIZE],
    idx: usize,
}

impl Buffer {
    pub fn new() -> Self {
        //let buf = cortex_m::singleton!(: [u8; DMA_TX_BUF_SIZE] = [0; DMA_TX_BUF_SIZE]).unwrap();
        let buf: [u8; DMA_TX_BUF_SIZE] = [0; DMA_TX_BUF_SIZE];

        Self { buf, idx: 0 }
    }
    pub fn clear(&mut self) {
        self.idx = 0;
    }
}

impl Debug for Buffer {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        write!(f, "{:?}", &self.buf[0..self.idx])
    }
}

//impl Deref for Buffer {
//type Target = &'static [u8];
//fn deref(&self) -> &Self::Target {
//&self.buf[..]
//}
//}

//impl DerefMut for Buffer {
//fn deref_mut(&mut self) -> &mut Self::Target {
//&mut &self.buf[..]
//}
//}

impl AsSlice for Buffer {
    type Element = u8;
    fn as_slice(&self) -> &[u8] {
        &self.buf[0..self.idx]
    }
}

impl SerFlavor for &'static mut Buffer {
    type Output = &'static mut Buffer;
    fn try_push(&mut self, data: u8) -> Result<(), ()> {
        self.buf[self.idx] = data;
        self.idx += 1;
        Ok(())
    }

    fn release(self) -> Result<Self::Output, ()> {
        Ok(self)
    }

    fn try_extend(&mut self, data: &[u8]) -> Result<(), ()> {
        self.buf[self.idx..].copy_from_slice(data);
        self.idx = self.idx + data.len();
        Ok(())
    }
}

impl Index<usize> for &'static mut Buffer {
    type Output = u8;
    fn index(&self, index: usize) -> &Self::Output {
        &self.buf[index]
    }
}

impl IndexMut<usize> for &'static mut Buffer {
    fn index_mut(&mut self, index: usize) -> &mut Self::Output {
        &mut self.buf[index]
    }
}

pub struct SerialSender {
    tx: Option<TxDma3>,
    buf: Option<&'static mut Buffer>,
}

impl SerialSender {
    pub fn new(tx: TxDma3) -> Self {
        let tx_buf = cortex_m::singleton!(: Buffer = Buffer::new()).unwrap();
        Self {
            tx: Some(tx),
            buf: Some(tx_buf),
        }
    }
    pub fn send(&mut self, msg: Message) {
        let buf = self.buf.take().unwrap();

        let buf = serialize_with_flavor::<Message, Cobs<&'static mut Buffer>, &'static mut Buffer>(
            &msg,
            Cobs::try_new(buf).unwrap(),
        )
        .unwrap();

        let tx = self.tx.take().unwrap();
        let transfer = tx.write(buf);
        let (buf, tx) = transfer.wait();
        buf.clear();
        self.tx = Some(tx);
        self.buf = Some(buf);
    }
}

pub struct SerialReceiver {
    rx: Option<Transfer<dma::W, &'static mut [u8; DMA_RX_BUF_SIZE], RxDma3>>,
    buf: Vec<u8, U256>,
    skip: usize,
}

impl SerialReceiver {
    pub fn new(rx: RxDma3) -> Self {
        let buf = cortex_m::singleton!(: [u8; DMA_RX_BUF_SIZE] = [0; DMA_RX_BUF_SIZE]).unwrap();
        let transfer: Transfer<dma::W, &'static mut [u8; DMA_RX_BUF_SIZE], RxDma3> = rx.read(buf);
        Self {
            rx: Some(transfer),
            buf: Vec::new(),
            skip: 0,
        }
    }

    pub fn peek(&mut self) -> Option<Message> {
        if let Some(ref s) = self.rx {
            let buf = s.peek();

            for b in &buf[self.skip..] {
                self.buf.push(*b).unwrap();
                self.skip += 1;
                if *b == 0 {
                    let msg = match from_bytes_cobs::<Message>(&mut self.buf) {
                        Ok(msg) => Some(msg),
                        Err(_) => None,
                    };

                    self.buf.clear();
                    return msg;
                }
            }
        }
        None
    }

    pub fn wait(&mut self) -> Option<Message> {
        let msg = self.peek();
        self.reset();
        msg
    }
    pub fn reset(&mut self) {
        self.skip = 0;
        let transfer = self.rx.take().unwrap();
        let (buf, rx) = transfer.wait();
        let transfer: Transfer<dma::W, &'static mut [u8; DMA_RX_BUF_SIZE], RxDma3> = rx.read(buf);
        self.rx = Some(transfer);
    }
}

#![no_main]
#![no_std]
//extern crate panic_itm; // panic handler
//

use cortex_m_semihosting::hprintln;
use panic_semihosting as _;

use cortex_m;
use cortex_m_rt::entry;
use stm32f1xx_hal::adc;
use stm32f1xx_hal::delay::Delay;
use stm32f1xx_hal::prelude::*;
use stm32f1xx_hal::stm32;

use embedded_hal::digital::v2::OutputPin;

#[entry]
fn main() -> ! {
    let cp = cortex_m::Peripherals::take().unwrap();
    let dp = stm32::Peripherals::take().unwrap();

    let mut flash = dp.FLASH.constrain();
    let mut rcc = dp.RCC.constrain();
    //let clocks = rcc.cfgr.freeze(&mut flash.acr);
    let clocks = rcc
        .cfgr
        .use_hse(8.mhz())
        .sysclk(56.mhz())
        .pclk1(28.mhz())
        .adcclk(14.mhz())
        .freeze(&mut flash.acr);
    hprintln!("sysclk freq: {}", clocks.sysclk().0).unwrap();
    hprintln!("adc freq: {}", clocks.adcclk().0).unwrap();
    // Setup ADC
    let mut adc = adc::Adc::adc1(dp.ADC1, &mut rcc.apb2, clocks);

    // Configure pb0, pb1 as an analog input
    let mut gpioa = dp.GPIOA.split(&mut rcc.apb2);

    let mut ch0 = gpioa.pa6.into_analog(&mut gpioa.crl);

    // Acquire the GPIOC peripheral
    let mut gpioc = dp.GPIOC.split(&mut rcc.apb2);

    // Configure gpio C pin 13 as a push-pull output. The `crh` register is passed to the function
    // in order to configure the port. For pins 0-7, crl should be passed instead.
    let mut led = gpioc.pc13.into_push_pull_output(&mut gpioc.crh);

    let mut delay = Delay::new(cp.SYST, clocks);
    loop {
        let data: u16 = adc.read(&mut ch0).unwrap();
        hprintln!("temp: {}", data).unwrap();
        led.set_high();
        delay.delay_ms(1000 as u16);
        led.set_low();
        delay.delay_ms(1000 as u16);
    }
}

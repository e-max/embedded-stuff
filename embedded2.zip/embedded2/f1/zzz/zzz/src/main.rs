//! examples/init.rs

#![deny(unsafe_code)]
#![deny(warnings)]
#![no_main]
#![no_std]

use cortex_m_semihosting::{debug, hprintln};
use panic_semihosting as _;

use stm32f1xx_hal::delay::Delay;
use stm32f1xx_hal::dma;
use stm32f1xx_hal::pac;
use stm32f1xx_hal::prelude::*;
use stm32f1xx_hal::serial::{Config, RxDma1, Serial, TxDma1};
use stm32f1xx_hal::timer::{self, CountDownTimer, Timer};

//use ufmt::uwrite;

use template_rtfm::messages::Message;
use template_rtfm::usart_messenger::{Baudrate, SerialReceiver, SerialSender};

#[rtfm::app(device = stm32f1xx_hal::pac, peripherals = true)]
const APP: () = {
    struct Resources {
        delay: Delay,

        serial_receiver: SerialReceiver<RxDma1>,
        serial_sender: SerialSender<TxDma1>,
        ticker: CountDownTimer<pac::TIM1>,
    }

    #[init]
    fn init(cx: init::Context) -> init::LateResources {
        // Cortex-M peripherals
        let core: cortex_m::Peripherals = cx.core;

        // Device specific peripherals
        let device: stm32f1xx_hal::pac::Peripherals = cx.device;

        hprintln!("init").unwrap();

        let mut flash = device.FLASH.constrain();
        let mut rcc = device.RCC.constrain();

        let clocks = rcc
            .cfgr
            .use_hse(8.mhz())
            .sysclk(72.mhz())
            .pclk1(36.mhz())
            .pclk2(72.mhz())
            .freeze(&mut flash.acr);
        //hprintln!("sysclk freq: {}", clocks.sysclk().0).unwrap();

        let delay = Delay::new(core.SYST, clocks);

        // Prepare the alternate function I/O registers
        let mut afio = device.AFIO.constrain(&mut rcc.apb2);

        // prepare Serial
        let mut gpioa = device.GPIOA.split(&mut rcc.apb2);

        // USART3
        // Configure pb10 as a push_pull output, this will be the tx pin
        let tx = gpioa.pa9.into_alternate_push_pull(&mut gpioa.crh);
        // Take ownership over pb11
        let rx = gpioa.pa10;

        let channels = device.DMA1.split(&mut rcc.ahb);

        // Set up the usart device. Taks ownership over the USART register and tx/rx pins. The rest of
        // the registers are used to enable and configure the device.
        let serial = Serial::usart1(
            device.USART1,
            (tx, rx),
            &mut afio.mapr,
            Config::default().baudrate((Baudrate::Low as u32).bps()),
            clocks,
            &mut rcc.apb2,
        );

        let (tx, rx) = serial.split();

        let tx = tx.with_dma(channels.4);

        let mut rx = rx.with_dma(channels.5);
        rx.channel.listen(dma::Event::TransferComplete);

        let serial_receiver = SerialReceiver::new(rx);
        let mut serial_sender = SerialSender::new(tx);

        let mut ticker = Timer::tim1(device.TIM1, &clocks, &mut rcc.apb2).start_count_down(1.hz());
        ticker.listen(timer::Event::Update);

        debug::exit(debug::EXIT_SUCCESS);
        // Init the static resources to use them later through RTFM
        return init::LateResources {
            delay,
            serial_receiver,
            serial_sender,
            ticker,
        };
    }

    #[task(resources = [serial_sender])]
    fn send(cx: send::Context, msg: Message) {
        cx.resources.serial_sender.send(msg);
    }

    #[idle(spawn = [send],  resources = [])]
    fn idle(_cx: idle::Context) -> ! {
        loop {
            cortex_m::asm::wfi();
        }
    }

    #[task(priority = 1, capacity=4, resources = [serial_sender])]
    fn process_message(cx: process_message::Context, msg: Message) {
        cx.resources.serial_sender.send(msg);
        //match msg {
        //Message::Msg(txt) => {}
        //Message::Coord { x, y } => {}
        //Message::List(vec) => {}
        //Message::U32(n) => {}
        //}
    }

    #[task(binds = DMA1_CHANNEL5, priority = 2, spawn = [send, process_message], resources = [serial_receiver])]
    fn serial_dma(cx: serial_dma::Context) {
        while let Some(msg) = cx.resources.serial_receiver.peek() {
            cx.spawn.process_message(msg).unwrap();
        }
        cx.resources.serial_receiver.reset();
    }

    #[task(binds = TIM1_UP, priority = 1, spawn = [send, process_message], resources = [serial_receiver, ticker])]
    fn tick(mut cx: tick::Context) {
        while let Some(msg) = cx.resources.serial_receiver.lock(|sr| sr.peek()) {
            cx.spawn.process_message(msg).unwrap()
        }
        cx.resources.ticker.clear_update_interrupt_flag();
    }

    extern "C" {
        fn UART5();
        fn UART4();
    }
};

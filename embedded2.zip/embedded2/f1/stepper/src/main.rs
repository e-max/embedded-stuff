#![no_main]
#![no_std]
//extern crate panic_itm; // panic handler
//
//
use core::fmt::Write;

use cortex_m_semihosting::hprintln;
use panic_semihosting as _;

use cortex_m;
use cortex_m_rt::entry;
use stm32f1xx_hal::delay::Delay;
use stm32f1xx_hal::gpio::{Output, PushPull, Pxx};
use stm32f1xx_hal::prelude::*;
use stm32f1xx_hal::serial::{Config, Serial};
use stm32f1xx_hal::stm32;

use embedded_hal::digital::v2::OutputPin;

use nb::block;

const STEPS: u8 = 64;
const GEAR: u8 = 64;
const STEP_PER_DEGREE: u32 = STEPS as u32 * GEAR as u32 / 360;

type StepperPin = Pxx<Output<PushPull>>;

struct Stepper {
    pins: [StepperPin; 4],
    delay: Delay,
}

impl Stepper {
    pub fn new(
        pin1: StepperPin,
        pin2: StepperPin,
        pin3: StepperPin,
        pin4: StepperPin,
        delay: Delay,
    ) -> Self {
        Stepper {
            pins: [pin1, pin2, pin3, pin4],
            delay,
        }
    }
    pub fn next_step(&mut self) {
        let mut next = self.cur_step() + 1;
        if next == 8 {
            next = 0;
        }
        self.step(next);
    }

    pub fn prev_step(&mut self) {
        let mut next = self.cur_step().checked_sub(1).unwrap_or(7);
        self.step(next);
    }

    pub fn run(&mut self) {
        for i in 0..(STEPS as u32 * GEAR as u32) {
            self.next_step();
            self.delay.delay_ms(1 as u16);
        }
    }

    pub fn rotate(&mut self, degrees: i16) {
        if degrees > 0 {
            for _ in 0..STEP_PER_DEGREE * degrees.abs() as u32 {
                self.next_step();
                self.delay.delay_ms(1 as u16);
            }
        } else {
            for _ in 0..STEP_PER_DEGREE * degrees.abs() as u32 {
                self.prev_step();
                self.delay.delay_ms(1 as u16);
            }
        }
    }

    fn set_only(&mut self, n: u8) {
        for i in 0..4 {
            if i == n {
                self.pins[i as usize].set_high();
            } else {
                self.pins[i as usize].set_low();
            }
        }
    }
    fn set_pair(&mut self, n: u8) {
        for i in 0..4 {
            if i == n || (i == n + 1 && n < 3) || (i == 0 && n == 3) {
                self.pins[i as usize].set_high();
            } else {
                self.pins[i as usize].set_low();
            }
        }
    }
    fn step(&mut self, n: u8) {
        if n % 2 == 0 {
            self.set_only(n / 2);
        } else {
            self.set_pair(n / 2);
        }
    }
    pub fn cur_step(&self) -> u8 {
        match (
            self.pins[0].is_set_high(),
            self.pins[1].is_set_high(),
            self.pins[2].is_set_high(),
            self.pins[3].is_set_high(),
        ) {
            (Ok(true), Ok(false), Ok(false), Ok(false)) => 0,
            (Ok(true), Ok(true), Ok(false), Ok(false)) => 1,
            (Ok(false), Ok(true), Ok(false), Ok(false)) => 2,
            (Ok(false), Ok(true), Ok(true), Ok(false)) => 3,
            (Ok(false), Ok(false), Ok(true), Ok(false)) => 4,
            (Ok(false), Ok(false), Ok(true), Ok(true)) => 5,
            (Ok(false), Ok(false), Ok(false), Ok(true)) => 6,
            (Ok(true), Ok(false), Ok(false), Ok(true)) => 7,
            (_, _, _, _) => 0,
        }
    }
}

#[entry]
fn main() -> ! {
    let cp = cortex_m::Peripherals::take().unwrap();
    let dp = stm32::Peripherals::take().unwrap();

    let mut flash = dp.FLASH.constrain();
    let mut rcc = dp.RCC.constrain();
    //let clocks = rcc.cfgr.freeze(&mut flash.acr);
    let clocks = rcc
        .cfgr
        .use_hse(8.mhz())
        .sysclk(56.mhz())
        .pclk1(28.mhz())
        .freeze(&mut flash.acr);
    hprintln!("sysclk freq: {}", clocks.sysclk().0).unwrap();

    // Configure pb0, pb1 as an analog input
    let mut gpioa = dp.GPIOA.split(&mut rcc.apb2);

    let mut pa8 = gpioa.pa8.into_push_pull_output(&mut gpioa.crh);
    let mut pa9 = gpioa.pa9.into_push_pull_output(&mut gpioa.crh);
    let mut pa10 = gpioa.pa10.into_push_pull_output(&mut gpioa.crh);
    let mut pa11 = gpioa.pa11.into_push_pull_output(&mut gpioa.crh);

    let mut delay = Delay::new(cp.SYST, clocks);

    // Prepare the alternate function I/O registers
    let mut afio = dp.AFIO.constrain(&mut rcc.apb2);

    // Configure pb0, pb1 as an analog input
    let mut gpiob = dp.GPIOB.split(&mut rcc.apb2);

    // USART3
    // Configure pb10 as a push_pull output, this will be the tx pin
    let tx = gpiob.pb10.into_alternate_push_pull(&mut gpiob.crh);
    // Take ownership over pb11
    let rx = gpiob.pb11;

    // Set up the usart device. Taks ownership over the USART register and tx/rx pins. The rest of
    // the registers are used to enable and configure the device.
    let serial = Serial::usart3(
        dp.USART3,
        (tx, rx),
        &mut afio.mapr,
        Config::default().baudrate(115200.bps()),
        clocks,
        &mut rcc.apb1,
    );

    let (mut tx, mut rx) = serial.split();
    loop {
        // Split the serial struct into a receiving and a transmitting part

        let number = 103;

        let received = block!(rx.read()).unwrap();
        hprintln!("got: {}", received).unwrap();
        writeln!(tx, "Hello formatted string {}", received).unwrap();
        //delay.delay_ms(1000 as u16);
    }

    let mut stepper = Stepper::new(
        pa8.downgrade(),
        pa9.downgrade(),
        pa10.downgrade(),
        pa11.downgrade(),
        delay,
    );
    stepper.rotate(180);
    stepper.rotate(-90);
    stepper.rotate(30);
    loop {}
}

//! examples/init.rs

#![deny(unsafe_code)]
#![deny(warnings)]
#![no_main]
#![no_std]

use cortex_m::singleton;
use cortex_m_semihosting::{debug, hprintln};
use panic_semihosting as _;

use stm32f1xx_hal::adc;
use stm32f1xx_hal::delay::Delay;
use stm32f1xx_hal::dma;
use stm32f1xx_hal::gpio::{gpioa::PA0, Analog};
use stm32f1xx_hal::pac;
use stm32f1xx_hal::prelude::*;
use stm32f1xx_hal::serial::{Config, RxDma1, Serial, TxDma1};
use stm32f1xx_hal::timer::{self, CountDownTimer, Timer};

//use ufmt::uwrite;

use adc::messages::Message;
use adc::usart_messenger::{Baudrate, SerialReceiver, SerialSender};

#[rtfm::app(device = stm32f1xx_hal::pac, peripherals = true)]
const APP: () = {
    struct Resources {
        delay: Delay,

        serial_receiver: SerialReceiver<RxDma1>,
        serial_sender: SerialSender<TxDma1>,
        ticker: CountDownTimer<pac::TIM1>,

        adc1: adc::Adc<pac::ADC1>,
        adc_ch0: PA0<Analog>,
        adc_ticker: CountDownTimer<pac::TIM2>,
    }

    #[init]
    fn init(cx: init::Context) -> init::LateResources {
        // Cortex-M peripherals
        let core: cortex_m::Peripherals = cx.core;

        // Device specific peripherals
        let device: stm32f1xx_hal::pac::Peripherals = cx.device;

        hprintln!("init").unwrap();

        let mut flash = device.FLASH.constrain();
        let mut rcc = device.RCC.constrain();

        let clocks = rcc
            .cfgr
            .use_hse(8.mhz())
            .sysclk(72.mhz())
            .pclk1(36.mhz())
            .pclk2(72.mhz())
            .freeze(&mut flash.acr);
        //hprintln!("sysclk freq: {}", clocks.sysclk().0).unwrap();

        let delay = Delay::new(core.SYST, clocks);

        // Prepare the alternate function I/O registers
        let mut afio = device.AFIO.constrain(&mut rcc.apb2);

        // prepare Serial
        let mut gpioa = device.GPIOA.split(&mut rcc.apb2);

        // USART3
        // Configure pb10 as a push_pull output, this will be the tx pin
        let tx = gpioa.pa9.into_alternate_push_pull(&mut gpioa.crh);
        // Take ownership over pb11
        let rx = gpioa.pa10;

        let channels = device.DMA1.split(&mut rcc.ahb);

        // Set up the usart device. Taks ownership over the USART register and tx/rx pins. The rest of
        // the registers are used to enable and configure the device.
        let serial = Serial::usart1(
            device.USART1,
            (tx, rx),
            &mut afio.mapr,
            Config::default().baudrate((Baudrate::Low as u32).bps()),
            clocks,
            &mut rcc.apb2,
        );

        let (tx, rx) = serial.split();

        let tx = tx.with_dma(channels.4);

        let mut rx = rx.with_dma(channels.5);
        rx.channel.listen(dma::Event::TransferComplete);

        let serial_receiver = SerialReceiver::new(rx);
        let serial_sender = SerialSender::new(tx);

        let mut ticker = Timer::tim1(device.TIM1, &clocks, &mut rcc.apb2).start_count_down(1.hz());
        ticker.listen(timer::Event::Update);

        // Setup ADC
        let adc1: adc::Adc<pac::ADC1> = adc::Adc::adc1(device.ADC1, &mut rcc.apb2, clocks);
        // Configure pa0 as an analog input
        let adc_ch0: PA0<Analog> = gpioa.pa0.into_analog(&mut gpioa.crl);

        let mut adc_ticker =
            Timer::tim2(device.TIM2, &clocks, &mut rcc.apb1).start_count_down(1.hz());
        adc_ticker.listen(timer::Event::Update);

        let adc_dma = adc1.with_dma(adc_ch0, channels.1);
        let buf = singleton!(: [u16; 8] = [0; 8]).unwrap();
        //let rxdma = adc_dma.read(buf);

        // The read method consumes the buf and self, starts the adc and dma transfer and returns a
        // RxDma struct. The wait method consumes the RxDma struct, waits for the whole transfer to be
        // completed and then returns the updated buf and underlying adc_dma struct. For non blocking,
        // one can call the is_done method of RxDma and only call wait after that method returns true.
        let (buf, adc_dma) = adc_dma.read(buf).wait();
        let (adc1, adc_ch0, _) = adc_dma.split();

        hprintln!(" buf {:?}", buf).unwrap();

        debug::exit(debug::EXIT_SUCCESS);
        // Init the static resources to use them later through RTFM
        return init::LateResources {
            delay,
            serial_receiver,
            serial_sender,
            ticker,
            adc1,
            adc_ch0,
            adc_ticker,
        };
    }

    #[task(resources = [serial_sender])]
    fn send(cx: send::Context, msg: Message) {
        cx.resources.serial_sender.send(msg);
    }

    #[idle(spawn = [send],  resources = [])]
    fn idle(_cx: idle::Context) -> ! {
        loop {
            cortex_m::asm::wfi();
        }
    }

    #[task(priority = 1, capacity=4, resources = [serial_sender])]
    fn process_message(cx: process_message::Context, msg: Message) {
        cx.resources.serial_sender.send(msg);
        //match msg {
        //Message::Msg(txt) => {}
        //Message::Coord { x, y } => {}
        //Message::List(vec) => {}
        //Message::U32(n) => {}
        //}
    }

    #[task(binds = DMA1_CHANNEL5, priority = 2, spawn = [send, process_message], resources = [serial_receiver])]
    fn serial_dma(cx: serial_dma::Context) {
        while let Some(msg) = cx.resources.serial_receiver.peek() {
            cx.spawn.process_message(msg).unwrap();
        }
        cx.resources.serial_receiver.reset();
    }

    #[task(binds = TIM1_UP, priority = 1, spawn = [send, process_message], resources = [serial_receiver, ticker])]
    fn tick(mut cx: tick::Context) {
        while let Some(msg) = cx.resources.serial_receiver.lock(|sr| sr.peek()) {
            cx.spawn.process_message(msg).unwrap()
        }
        cx.resources.ticker.clear_update_interrupt_flag();
    }

    #[task(binds = TIM2, priority = 1, spawn = [send], resources = [adc_ticker, adc_ch0, adc1])]
    fn adc_tick(cx: adc_tick::Context) {
        let res: u32 = cx.resources.adc1.read(cx.resources.adc_ch0).unwrap();
        let msg = Message::U32(res);
        cx.spawn.send(msg).unwrap();
        cx.resources.adc_ticker.clear_update_interrupt_flag();
    }

    extern "C" {
        fn UART5();
        fn UART4();
    }
};

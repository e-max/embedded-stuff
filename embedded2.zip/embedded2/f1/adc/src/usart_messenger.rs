use core::fmt::Debug;
use core::ops::{Index, IndexMut};

use stm32f1xx_hal::dma::{self, ReadDma, Static, Transfer, WriteDma};
use stm32f1xx_hal::prelude::*;
use stm32f1xx_hal::serial::{RxDma1, RxDma2, RxDma3, TxDma1, TxDma2, TxDma3};

use heapless::{consts::U256, Vec};
use postcard::{self, flavors::Cobs, flavors::SerFlavor, from_bytes_cobs, serialize_with_flavor};

use as_slice::AsSlice;

use crate::messages::Message;

pub enum Baudrate {
    Low = 115_200,
    Middle = 921_600,
    High = 1_843_200,
}

const DMA_RX_BUF_SIZE: usize = 8;
const DMA_TX_BUF_SIZE: usize = 256;

pub struct Buffer {
    buf: [u8; DMA_TX_BUF_SIZE],
    idx: usize,
}

impl Buffer {
    pub fn new() -> Self {
        //let buf = cortex_m::singleton!(: [u8; DMA_TX_BUF_SIZE] = [0; DMA_TX_BUF_SIZE]).unwrap();
        let buf: [u8; DMA_TX_BUF_SIZE] = [0; DMA_TX_BUF_SIZE];

        Self { buf, idx: 0 }
    }
    pub fn clear(&mut self) {
        self.idx = 0;
    }
}

impl Debug for Buffer {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        write!(f, "{:?}", &self.buf[0..self.idx])
    }
}

//impl Deref for Buffer {
//type Target = &'static [u8];
//fn deref(&self) -> &Self::Target {
//&self.buf[..]
//}
//}

//impl DerefMut for Buffer {
//fn deref_mut(&mut self) -> &mut Self::Target {
//&mut &self.buf[..]
//}
//}

impl AsSlice for Buffer {
    type Element = u8;
    fn as_slice(&self) -> &[u8] {
        &self.buf[0..self.idx]
    }
}

impl SerFlavor for &'static mut Buffer {
    type Output = &'static mut Buffer;
    fn try_push(&mut self, data: u8) -> Result<(), ()> {
        self.buf[self.idx] = data;
        self.idx += 1;
        Ok(())
    }

    fn release(self) -> Result<Self::Output, ()> {
        Ok(self)
    }

    fn try_extend(&mut self, data: &[u8]) -> Result<(), ()> {
        self.buf[self.idx..].copy_from_slice(data);
        self.idx = self.idx + data.len();
        Ok(())
    }
}

impl Index<usize> for &'static mut Buffer {
    type Output = u8;
    fn index(&self, index: usize) -> &Self::Output {
        &self.buf[index]
    }
}

impl IndexMut<usize> for &'static mut Buffer {
    fn index_mut(&mut self, index: usize) -> &mut Self::Output {
        &mut self.buf[index]
    }
}

impl Static<&'static Buffer> for &'static Buffer {
    fn borrow(&self) -> &&'static Buffer {
        &self
    }
}

impl Static<&'static mut Buffer> for &'static mut Buffer {
    fn borrow(&self) -> &&'static mut Buffer {
        &self
    }
}

pub struct SerialSender<T> {
    tx: Option<T>,
    buf: Option<&'static mut Buffer>,
}

type TransferTx1 = Transfer<dma::R, &'static mut Buffer, TxDma1>;
type TransferTx2 = Transfer<dma::R, &'static mut Buffer, TxDma2>;
type TransferTx3 = Transfer<dma::R, &'static mut Buffer, TxDma3>;

pub trait Waiter<B, T> {
    fn wait(self) -> (B, T);
}

impl Waiter<&'static mut Buffer, TxDma1> for TransferTx1 {
    fn wait(self) -> (&'static mut Buffer, TxDma1) {
        TransferTx1::wait(self)
    }
}

impl Waiter<&'static mut Buffer, TxDma2> for TransferTx2 {
    fn wait(self) -> (&'static mut Buffer, TxDma2) {
        TransferTx2::wait(self)
    }
}

impl Waiter<&'static mut Buffer, TxDma3> for TransferTx3 {
    fn wait(self) -> (&'static mut Buffer, TxDma3) {
        TransferTx3::wait(self)
    }
}

impl<T> SerialSender<T>
where
    T: WriteDma<&'static mut Buffer, &'static mut Buffer, u8>,
    Transfer<dma::R, &'static mut Buffer, T>: Waiter<&'static mut Buffer, T>,
{
    pub fn new(tx: T) -> Self {
        let tx_buf = cortex_m::singleton!(: Buffer = Buffer::new()).unwrap();
        Self {
            tx: Some(tx),
            buf: Some(tx_buf),
        }
    }
    pub fn send(&mut self, msg: Message) {
        let buf = self.buf.take().unwrap();

        let buf = serialize_with_flavor::<Message, Cobs<&'static mut Buffer>, &'static mut Buffer>(
            &msg,
            Cobs::try_new(buf).unwrap(),
        )
        .unwrap();

        let tx = self.tx.take().unwrap();
        let transfer: Transfer<stm32f1xx_hal::dma::R, &'static mut Buffer, T> = tx.write(buf);
        let (buf, tx) = transfer.wait();
        buf.clear();
        self.tx = Some(tx);
        self.buf = Some(buf);
    }
}

type TransferRx<T> = Transfer<dma::W, &'static mut [u8; DMA_RX_BUF_SIZE], T>;
type TransferRx1 = TransferRx<RxDma1>;
type TransferRx2 = TransferRx<RxDma2>;
type TransferRx3 = TransferRx<RxDma3>;

pub trait Peek<T> {
    fn peek(&self) -> &[u8];
}

impl Peek<RxDma1> for TransferRx1 {
    fn peek(&self) -> &[u8] {
        TransferRx1::peek(self)
    }
}
impl Peek<RxDma2> for TransferRx2 {
    fn peek(&self) -> &[u8] {
        TransferRx2::peek(self)
    }
}
impl Peek<RxDma3> for TransferRx3 {
    fn peek(&self) -> &[u8] {
        TransferRx3::peek(self)
    }
}

impl Waiter<&'static mut [u8; DMA_RX_BUF_SIZE], RxDma1> for TransferRx1 {
    fn wait(self) -> (&'static mut [u8; DMA_RX_BUF_SIZE], RxDma1) {
        TransferRx1::wait(self)
    }
}

impl Waiter<&'static mut [u8; DMA_RX_BUF_SIZE], RxDma2> for TransferRx2 {
    fn wait(self) -> (&'static mut [u8; DMA_RX_BUF_SIZE], RxDma2) {
        TransferRx2::wait(self)
    }
}

impl Waiter<&'static mut [u8; DMA_RX_BUF_SIZE], RxDma3> for TransferRx3 {
    fn wait(self) -> (&'static mut [u8; DMA_RX_BUF_SIZE], RxDma3) {
        TransferRx3::wait(self)
    }
}

pub struct SerialReceiver<T> {
    rx: Option<TransferRx<T>>,
    buf: Vec<u8, U256>,
    skip: usize,
}

impl<T> SerialReceiver<T>
where
    T: ReadDma<[u8; DMA_RX_BUF_SIZE], u8>,
    TransferRx<T>: Peek<T>,
    TransferRx<T>: Waiter<&'static mut [u8; DMA_RX_BUF_SIZE], T>,
{
    pub fn new(rx: T) -> Self {
        let buf: &'static mut [u8; DMA_RX_BUF_SIZE] =
            cortex_m::singleton!(: [u8; DMA_RX_BUF_SIZE] = [0; DMA_RX_BUF_SIZE]).unwrap();
        let transfer = rx.read(buf);
        Self {
            rx: Some(transfer),
            buf: Vec::new(),
            skip: 0,
        }
    }

    pub fn peek(&mut self) -> Option<Message> {
        if let Some(ref s) = self.rx {
            let buf = s.peek();

            for b in &buf[self.skip..] {
                self.buf.push(*b).unwrap();
                self.skip += 1;
                if *b == 0 {
                    let msg = match from_bytes_cobs::<Message>(&mut self.buf) {
                        Ok(msg) => Some(msg),
                        Err(_) => None,
                    };

                    self.buf.clear();
                    return msg;
                }
            }
        }
        None
    }

    pub fn wait(&mut self) -> Option<Message> {
        let msg = self.peek();
        self.reset();
        msg
    }
    pub fn reset(&mut self) {
        self.skip = 0;
        let transfer = self.rx.take().unwrap();
        let (buf, rx) = transfer.wait();
        let transfer = rx.read(buf);
        self.rx = Some(transfer);
    }
}

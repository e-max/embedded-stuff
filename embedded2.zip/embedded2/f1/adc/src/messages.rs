use heapless::{consts::U256, String, Vec};
use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Debug, Clone)]
pub enum Message {
    Msg(String<U256>),
    Coord { x: u32, y: u32 },
    List(Vec<u8, U256>),
    U32(u32),
}

//! examples/init.rs

#![deny(unsafe_code)]
#![deny(warnings)]
#![no_main]
#![no_std]

use core::fmt::Debug;
use core::ops::{Index, IndexMut};
use cortex_m_semihosting::{debug, hprintln};
use panic_semihosting as _;

use embedded_hal::digital::v2::InputPin;
use embedded_hal::digital::v2::OutputPin;

use stm32f1xx_hal::delay::Delay;
use stm32f1xx_hal::dma::{self, Transfer};
use stm32f1xx_hal::gpio::ExtiPin;
use stm32f1xx_hal::gpio::{
    gpioa::PA8, gpioa::PA9, gpiob::PB12, gpioc::PC13, Edge, Floating, Input, Output, PushPull,
};
use stm32f1xx_hal::pac;
use stm32f1xx_hal::prelude::*;
use stm32f1xx_hal::pwm::{Pwm, C1, C2};
use stm32f1xx_hal::serial::{Config, Serial};
use stm32f1xx_hal::serial::{RxDma3, TxDma3};

use stm32f1xx_hal::timer::{self, CountDownTimer, Tim4NoRemap, Timer};

use as_slice::AsSlice;

use postcard::{self, flavors::Cobs, flavors::SerFlavor, from_bytes_cobs, serialize_with_flavor};
//use ufmt::uwrite;

use ultrasound_rtfm::messages::Message;

use heapless::{consts::U256, Vec};

const DMA_RX_BUF_SIZE: usize = 8;
const DMA_TX_BUF_SIZE: usize = 256;

struct Buffer {
    buf: [u8; DMA_TX_BUF_SIZE],
    idx: usize,
}

impl Buffer {
    pub fn new() -> Self {
        //let buf = cortex_m::singleton!(: [u8; DMA_TX_BUF_SIZE] = [0; DMA_TX_BUF_SIZE]).unwrap();
        let buf: [u8; DMA_TX_BUF_SIZE] = [0; DMA_TX_BUF_SIZE];

        Self { buf, idx: 0 }
    }
    pub fn clear(&mut self) {
        self.idx = 0;
    }
}

impl Debug for Buffer {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        write!(f, "{:?}", &self.buf[0..self.idx])
    }
}

//impl Deref for Buffer {
//type Target = &'static [u8];
//fn deref(&self) -> &Self::Target {
//&self.buf[..]
//}
//}

//impl DerefMut for Buffer {
//fn deref_mut(&mut self) -> &mut Self::Target {
//&mut &self.buf[..]
//}
//}

impl AsSlice for Buffer {
    type Element = u8;
    fn as_slice(&self) -> &[u8] {
        &self.buf[0..self.idx]
    }
}

impl SerFlavor for &'static mut Buffer {
    type Output = &'static mut Buffer;
    fn try_push(&mut self, data: u8) -> Result<(), ()> {
        self.buf[self.idx] = data;
        self.idx += 1;
        Ok(())
    }

    fn release(self) -> Result<Self::Output, ()> {
        Ok(self)
    }

    fn try_extend(&mut self, data: &[u8]) -> Result<(), ()> {
        self.buf[self.idx..].copy_from_slice(data);
        self.idx = self.idx + data.len();
        Ok(())
    }
}

impl Index<usize> for &'static mut Buffer {
    type Output = u8;
    fn index(&self, index: usize) -> &Self::Output {
        &self.buf[index]
    }
}

impl IndexMut<usize> for &'static mut Buffer {
    fn index_mut(&mut self, index: usize) -> &mut Self::Output {
        &mut self.buf[index]
    }
}

pub struct SerialSender {
    tx: Option<TxDma3>,
    buf: Option<&'static mut Buffer>,
}

impl SerialSender {
    pub fn new(tx: TxDma3) -> Self {
        let tx_buf = cortex_m::singleton!(: Buffer = Buffer::new()).unwrap();
        Self {
            tx: Some(tx),
            buf: Some(tx_buf),
        }
    }
    pub fn send(&mut self, msg: Message) {
        let buf = self.buf.take().unwrap();

        let buf = serialize_with_flavor::<Message, Cobs<&'static mut Buffer>, &'static mut Buffer>(
            &msg,
            Cobs::try_new(buf).unwrap(),
        )
        .unwrap();

        let tx = self.tx.take().unwrap();
        let transfer = tx.write(buf);
        let (buf, tx) = transfer.wait();
        buf.clear();
        self.tx = Some(tx);
        self.buf = Some(buf);
    }
}

pub struct SerialReceiver {
    rx: Option<Transfer<dma::W, &'static mut [u8; DMA_RX_BUF_SIZE], RxDma3>>,
    buf: Vec<u8, U256>,
    skip: usize,
}

impl SerialReceiver {
    pub fn new(rx: RxDma3) -> Self {
        let buf = cortex_m::singleton!(: [u8; DMA_RX_BUF_SIZE] = [0; DMA_RX_BUF_SIZE]).unwrap();
        let transfer: Transfer<dma::W, &'static mut [u8; DMA_RX_BUF_SIZE], RxDma3> = rx.read(buf);
        Self {
            rx: Some(transfer),
            buf: Vec::new(),
            skip: 0,
        }
    }

    fn peek(&mut self) -> Option<Message> {
        let mut msg = None;
        if let Some(ref s) = self.rx {
            let buf = s.peek();

            for b in &buf[self.skip..] {
                self.buf.push(*b).unwrap();
                self.skip += 1;
                if *b == 0 {
                    msg = match from_bytes_cobs::<Message>(&mut self.buf) {
                        Ok(msg) => Some(msg),
                        Err(_) => None,
                    };

                    self.buf.clear();
                }
            }
        }
        msg
    }

    pub fn wait(&mut self) -> Option<Message> {
        let msg = self.peek();
        self.reset();
        msg
    }
    pub fn reset(&mut self) {
        self.skip = 0;
        let transfer = self.rx.take().unwrap();
        let (buf, rx) = transfer.wait();
        let transfer: Transfer<dma::W, &'static mut [u8; DMA_RX_BUF_SIZE], RxDma3> = rx.read(buf);
        self.rx = Some(transfer);
    }
}

#[rtfm::app(device = stm32f1xx_hal::pac, peripherals = true)]
const APP: () = {
    struct Resources {
        led: PC13<Output<PushPull>>,
        delay: Delay,

        ultrasound_timer: CountDownTimer<pac::TIM2>,
        ultrasound_input: PA9<Input<Floating>>,
        ultrasound_trigger: PA8<Output<PushPull>>,

        button: PB12<Input<Floating>>,

        serial_receiver: SerialReceiver,
        serial_sender: SerialSender,

        #[init(false)]
        led_state: bool,

        #[init(0)]
        distance: u32,

        ticker: CountDownTimer<pac::TIM1>,

        pwm1: Pwm<pac::TIM4, C1>,
        pwm2: Pwm<pac::TIM4, C2>,
    }

    #[init]
    fn init(cx: init::Context) -> init::LateResources {
        static mut X: u32 = 0;

        // Cortex-M peripherals
        let core: cortex_m::Peripherals = cx.core;

        // Device specific peripherals
        let device: stm32f1xx_hal::pac::Peripherals = cx.device;

        // Safe access to local `static mut` variable
        let _x: &'static mut u32 = X;

        hprintln!("init").unwrap();

        let mut flash = device.FLASH.constrain();
        let mut rcc = device.RCC.constrain();

        let clocks = rcc
            .cfgr
            .use_hse(8.mhz())
            .sysclk(72.mhz())
            .pclk1(36.mhz())
            .freeze(&mut flash.acr);
        //hprintln!("sysclk freq: {}", clocks.sysclk().0).unwrap();

        let delay = Delay::new(core.SYST, clocks);

        // Prepare the alternate function I/O registers
        let mut afio = device.AFIO.constrain(&mut rcc.apb2);

        // timer we are going to use to control ultrasound sensor
        let ultrasound_timer =
            Timer::tim2(device.TIM2, &clocks, &mut rcc.apb1).start_count_down(1.hz());

        // prepare pa8 pa9 for ultrasound
        let mut gpioa = device.GPIOA.split(&mut rcc.apb2);
        let pa8 = gpioa.pa8.into_push_pull_output(&mut gpioa.crh);
        let mut pa9 = gpioa.pa9.into_floating_input(&mut gpioa.crh);

        pa9.make_interrupt_source(&mut afio);
        pa9.trigger_on_edge(&device.EXTI, Edge::RISING_FALLING);
        pa9.enable_interrupt(&device.EXTI);

        // prepare LED
        let mut gpioc = device.GPIOC.split(&mut rcc.apb2);
        let led = gpioc.pc13.into_push_pull_output(&mut gpioc.crh);

        // prepare Serial
        let mut gpiob = device.GPIOB.split(&mut rcc.apb2);

        // pin for button
        let mut pb12 = gpiob.pb12.into_floating_input(&mut gpiob.crh);
        pb12.make_interrupt_source(&mut afio);
        pb12.trigger_on_edge(&device.EXTI, Edge::RISING);
        pb12.enable_interrupt(&device.EXTI);

        // USART3
        // Configure pb10 as a push_pull output, this will be the tx pin
        let tx = gpiob.pb10.into_alternate_push_pull(&mut gpiob.crh);
        // Take ownership over pb11
        let rx = gpiob.pb11;

        let channels = device.DMA1.split(&mut rcc.ahb);

        // Set up the usart device. Taks ownership over the USART register and tx/rx pins. The rest of
        // the registers are used to enable and configure the device.
        let serial = Serial::usart3(
            device.USART3,
            (tx, rx),
            &mut afio.mapr,
            Config::default().baudrate(115200.bps()),
            clocks,
            &mut rcc.apb1,
        );

        let (tx, rx) = serial.split();

        let tx = tx.with_dma(channels.2);

        let mut rx = rx.with_dma(channels.3);
        rx.channel.listen(dma::Event::TransferComplete);

        let serial_receiver = SerialReceiver::new(rx);
        let serial_sender = SerialSender::new(tx);

        // Timer which ticks every second
        let mut ticker = Timer::tim1(device.TIM1, &clocks, &mut rcc.apb2).start_count_down(1.hz());
        ticker.listen(timer::Event::Update);

        // Set up PWM for robot
        // TIM4 (Only available with the "medium" density feature)
        let c1 = gpiob.pb6.into_alternate_push_pull(&mut gpiob.crl);
        let c2 = gpiob.pb7.into_alternate_push_pull(&mut gpiob.crl);
        let pins = (c1, c2);
        let (mut pwm1, mut pwm2) = Timer::tim4(device.TIM4, &clocks, &mut rcc.apb1)
            .pwm::<Tim4NoRemap, _, _, _>(pins, &mut afio.mapr, 1.khz());

        pwm1.enable();
        hprintln!("pwm1.get_max_duty() = {}", pwm1.get_max_duty()).unwrap();
        pwm2.enable();

        pwm1.set_duty(pwm1.get_max_duty() / 2);
        pwm2.set_duty(pwm2.get_max_duty() / 4);

        debug::exit(debug::EXIT_SUCCESS);
        // Init the static resources to use them later through RTFM
        return init::LateResources {
            led,
            ultrasound_timer,
            delay,
            ultrasound_input: pa9,
            ultrasound_trigger: pa8,
            serial_receiver,
            serial_sender,
            button: pb12,
            ticker,
            pwm1,
            pwm2,
        };
    }

    #[task(resources = [serial_sender])]
    fn send(cx: send::Context, msg: Message) {
        cx.resources.serial_sender.send(msg);
    }

    #[idle(spawn = [send],  resources = [led, ultrasound_timer, ultrasound_trigger, distance, delay])]
    fn idle(cx: idle::Context) -> ! {
        loop {
            cx.resources.ultrasound_trigger.set_high().unwrap();
            cx.resources.delay.delay_ms(10 as u32);
            cx.resources.ultrasound_trigger.set_low().unwrap();
            cx.resources.delay.delay_ms(1000 as u32);

            //let d = cx.resources.distance.lock(|d| *d);
            //msg = Message::U32(d / 58);

            //cx.spawn.send(msg.clone()).unwrap();
        }
        //loop {
        //cortex_m::asm::wfi();
        //}
    }

    #[task(priority = 1, capacity=4, resources = [serial_sender])]
    fn process_message(cx: process_message::Context, msg: Message) {
        cx.resources.serial_sender.send(msg);
        //match msg {
        //Message::Msg(txt) => {}
        //Message::Coord { x, y } => {}
        //Message::List(vec) => {}
        //Message::U32(n) => {}
        //}
    }

    #[task(binds = DMA1_CHANNEL3, priority = 2, spawn = [send, process_message], resources = [serial_receiver])]
    fn serial_dma(cx: serial_dma::Context) {
        while let Some(msg) = cx.resources.serial_receiver.peek() {
            cx.spawn.process_message(msg).unwrap();
        }
        cx.resources.serial_receiver.reset();
    }

    #[task(binds = EXTI9_5, priority = 1, spawn = [send], resources = [led, ultrasound_timer, ultrasound_input, distance, button])]
    fn exti(cx: exti::Context) {
        if cx.resources.ultrasound_input.check_interrupt() {
            if cx.resources.ultrasound_input.is_high().unwrap() {
                cx.resources.ultrasound_timer.reset();
            } else {
                *cx.resources.distance = cx.resources.ultrasound_timer.micros_since();
            }
            let msg = Message::U32(*cx.resources.distance / 58);
            cx.spawn.send(msg.clone()).unwrap();

            // if we don't clear this bit, the ISR would trigger indefinitely
            cx.resources.ultrasound_input.clear_interrupt_pending_bit();
        }
    }

    #[task(binds = EXTI15_10, priority = 1, spawn = [send], resources = [led, ultrasound_input, distance, button])]
    fn exti2(cx: exti2::Context) {
        if cx.resources.button.check_interrupt() {
            cx.resources.led.toggle().unwrap();
            let msg = Message::Msg("button".into());
            cx.spawn.send(msg.clone()).unwrap();
            cx.resources.button.clear_interrupt_pending_bit();
        }
    }

    #[task(binds = TIM1_UP, priority = 1, spawn = [send, process_message], resources = [serial_receiver, ticker])]
    fn tick(mut cx: tick::Context) {
        while let Some(msg) = cx.resources.serial_receiver.lock(|sr| sr.peek()) {
            cx.spawn.process_message(msg).unwrap()
        }
        cx.resources.ticker.clear_update_interrupt_flag();
    }

    extern "C" {
        fn UART5();
        fn UART4();
    }
};
